# Importation d'un véhicule de transport chinois en Russie / l'EAEU: homologation de type, ERA-GLONASS et les documents qui doivent être d'accord
## OEuvre Métadonnées
- ** Titre du référencement**: Importer un véhicule de transport chinois en Russie: EAEU Type Agrément & Customs Path
- **Description détaillée**: La route Russie/UEA pour une EV chinoise — TR CU 018/2011 OTTC vs SBKTS, ERA-GLONASS en vertu du règlement, EPTS, la règle de la Chine 2026 pour les licences d'exportation, et exactement ce qu'il faut confirmer avant de payer.
- **URL suggérée**: /guides/import-chine-ev-to-russie-eac-ottc/
- ** H1 **: Comment un véhicule électrique chinois efface la Russie / l'UEA: Route de la conformité et douane Paperwork
- **Mot-clé principal**: importation de VE chinois en Russie EAEU OTT SBKTS douanes
- **Conditions de recherche secondaires**: TR CU 018/2011 véhicules à roues, EAEU réception de type de véhicule, SBKTS certificat de véhicule unique, exigence ERA-GLONASS, EPTS passeport électronique, permis d'exportation de véhicules EV en Chine 2026
- **Suggestions de lien interne**: /guides/véhicule-importation-paiement-tt-vs-lc/; /guides/marine-cargo-assurance-automobile-importation/; /guides/vérify-china-voiture-exportation-fournisseur/
- **Suggestions d'image**: diagramme de route OTTC-versus-SBKTS; marque de conformité EAC; terminal ERA-GLONASS et bouton SOS; flux de cohérence du nom du document
- ** Suggestions concernant les ALT**: "Lignes de certification des véhicules EAEU OTTC versus SBKTS"; "Marque de conformité EAC"; "documents qui doivent nommer le même importateur et le même numéro d'identification"
## Le problème réel pour un importateur B2B
Un véhicule de transport chinois n'atteint un acheteur russe qu'après trois étapes: un document de conformité **valide de l'EAEU**, une disposition d'appel d'urgence acceptée pour l'enregistrement** et un ensemble de documents et de douanes dont les personnes morales sont rapprochées au travers du certificat de conformité, de l'importateur d'enregistrement et de la facture**. Dans la pratique, les expéditions se heurtent le plus souvent à des problèmes lorsque ces documents désignent différentes parties ou lorsqu'un certificat par unité doit se comporter comme une approbation de type de lot. Cette étape est présentée comme une étape de contrôle des risques liés à l'approvisionnement; les exigences précises en matière d'entité juridique pour une route donnée devraient être confirmées auprès de l'organisme accrédité et d'un courtier en douane. Ce guide est spécifique à **la Russie au sein de l'Union économique eurasienne (UEE)**; il ne s'agit pas d'une déclaration générique "CIS" et il sépare délibérément la réglementation qui est réglée des points de coûts/processus qui changent et qui doit être confirmée en direct.
## La base réglée: TR CU 018/2011
Les véhicules routiers électriques, hybrides rechargeables et hybrides relèvent du champ d'application obligatoire du règlement technique TR CU 018/2011 de l'EAEU «Sur la sécurité des véhicules à roues»**. Le règlement a été adopté par la décision de la Commission de l'union douanière no 877 de 9 décembre 2011 et est entré en vigueur le janvier 1 2015 ** (le registre juridique officiel de l'UEA porte le texte consolidé; VERIFIED). Il s'applique aux véhicules de catégorie L/M/N/O; les véhicules routiers ordinaires ne peuvent bénéficier des exemptions restreintes (race, matériel militaire, certaines machines agricoles). Deux itinéraires de conformité en découlent:
| Itinéraire | Qu'est-ce que c'est | Quand ça va |
|---|---|---|
| **OTTC** — Homologation de type de véhicule (Одоошрение тияа шш) | Homologation de type entier pour une série, détenue par un fabricant ou un importateur de documents établis dans l'UEA | Envois répétés de B2B du même modèle; le chemin évolutif |
| **SBKTS** — Certificat de sécurité pour un véhicule (L'Equipement) (L'Equipement) | Évaluation de la sécurité par véhicule, avec un EPTS émis sur cette base | Unités individuelles et véhicules d'occasion, sans OTC |
Un EV reçoit alors un **EPTS (passeport électronique de véhicule)** et ne peut être enregistré auprès de l'autorité de la circulation que sur un EPTS valide. Pour un programme de flotte, le budget d'un OTC détenu par une entité EAEU bien établie; par unité, le SBKTS est lent et n'élargit pas. Engager un organisme/laboratoire de certification agréé par l'EAEU** tôt — les délais d'essai et de documentation dépassent généralement le transit océanique.
## ERA-GLONASS: une exigence réglementaire avec des détails de mise en œuvre changeants
The emergency-call system (**ERA-GLONASS / УВЭОС**) is part of the TR CU 018/2011 framework for M/N-category vehicles placed on the EAEU market — that requirement is regulatory and durable. Ce qui a changé ** à plusieurs reprises est le traitement des véhicules importés à titre personnel ou individuel**: Des exemptions temporaires pour les importations individuelles ont été introduites, renforcées et réimposées à différentes dates. Comme ces fenêtres d'exemption sont définies par des décisions d'application distinctes et n'ont pas été saisies dans une source russe officielle pour cet article, ne **pas** se fier à une date de rétablissement indiquée par les médias. Avant de commander, obtenir de l'organisme accrédité une réponse écrite à trois questions concrètes: (1) si votre unité/route particulière nécessite un terminal activé; (2) quels dispositifs et centres d'installation sont agréés; et (3) comment l'exigence diffère entre une importation par lot d'entité légale et une importation individuelle. Ne présumez pas qu'une unité d'appel électronique du marché chinois satisfait aux exigences de l'ERA-GLONASS/-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
## Droits, TVA, frais d'utilisation et d'acheminement: Vérifier — Ne pas citer les numéros de médias
Plusieurs points de coût et de routage circulent dans les médias de l'industrie russe avec des chiffres **incohérents**, ce qui est lui-même l'avertissement:
- **Droit d'importation pour les véhicules électriques**: outlets disagree sharply, with some citing a zero rate for HS 8703.80 and others a high percentage from a given 2026 date. Aucune décision principale du Service fédéral des douanes (SDF) ou de la Commission économique eurasienne n'a été prise ici, de sorte que ** aucun pourcentage de droits n'est déclaré comme fait**. Classer le code SH exact et lire le tarif douanier commun de l'UEA actuel, plus toute décision temporaire avant de construire une feuille de coût au débarquement.
- **Importation de la TVA et frais de recyclage/utilisation (утильсюор)**: La TVA est régie par le code fiscal russe et les frais d'utilisation par une annexe distincte qui est révisée périodiquement; confirmer les taux actuels et la catégorie d'importateur avec FTS / un courtier en douane accrédité au lieu de copier un chiffre de presse.
- **"Importation directe seulement / pas de transit via le Belarus, le Kazakhstan, le Kirghizistan"**: cette revendication apparaît dans un guide de l'industrie 2026 sans source principale d'instruction douanière capturée. Traiter le routage triangulaire de l'UEAE comme un point ** à confirmer par écrit auprès du conseil des douanes**, jamais comme une interdiction ou une autorisation établie.
Construction de coût au débarquement en tant que pile confirmée par le FTS** — droit + TVA + frais d'utilisation + certification + ERA-GLONASS montage + logistique + assurance — pas en tant que pourcentage emprunté unique.
## Le côté chinois: la règle de licence d'exportation 2026 est désormais officielle
Contrairement aux points de coût ci-dessus, le contrôle des exportations chinois est maintenant ancré dans les documents primaires (VERIFIED):
- **MOFCOM General Office Notice on the 2026 automobile/motorcycle export-licence application (商办贸函〔2025〕408号, 28 Sep 2025)** sets the online application system (ecomp.licence.org.cn), local-commerce preliminary review and the published qualified-enterprise list.
- ** L'annonce conjointe no 54 (2025) de MOFCOM, MIIT, GAC et SAMR** met en place des véhicules de tourisme à énergie pure (référence HS 8703801090) sous un régime de licence d'exportation de 1 janvier 2026 **.
- La liste ** 2026 des entreprises habilitées à demander des licences d'exportation de véhicules** a été publiée sur 30 déc 2025.
Sur le plan opérationnel, cela signifie que votre contrepartie chinoise doit pouvoir afficher, pour le modèle exact: qualification d'exportation valide / une place sur la liste actuelle, autorisation de marque, et documentation de transport de batterie (par exemple, UN38.3). Voir le guide de vérification du fournisseur pour la méthode de la chaîne d'autorisation.
## Ce qu'autoBridge ajoute au-delà d'un résumé de conformité
Des guides génériques citent les mêmes acronymes sans résoudre l'affaire. Notre cadre d'approvisionnement éditorial recommande (i) un rapprochement d'une page entre le titulaire de la conformité, l'importateur douanier d'enregistrement et la partie chargée de la facture, (ii) la décision OTTC-ou-SBKTS pour chaque NIV avant la signature du PI, et (iii) la vérification de l'exportateur chinois par rapport à la liste de licences MOFCOM de l'année en cours et à la règle 2026 de licences de passagers VR pur — les points où un défaut de concordance (importateur d'enregistrement; exportateur de VE non autorisé) bloque le plus souvent une expédition.
## Séquence de fonctionnement
1. Fixer le modèle/variante et décider OTTC (bateau) par rapport à SBKTS (unique/utilisé); passer un contrat avec un organisme agréé par l'UEA et obtenir une portée/une échéance écrite.
2. Établir l'importateur de l'UEA qui a été enregistré et rapprocher cette entité dans le cadre du dépôt OTC/SBKTS, du contrat, de la facture et des douanes (voir confirmation écrite lorsque le titulaire de la conformité diffère du destinataire).
3. Obtenez une confirmation écrite de l'exigence ERA-GLONASS, de l'appareil/du dispositif approuvé et des coûts pour votre catégorie d'importation.
4. Classer le SH 8703.80 et obtenir les chiffres **current** des droits/TVA/frais d'utilisation auprès de sources FTS/CEE avant de signer.
5. Vérifier le statut d'exportation de 2026 de l'exportateur chinois, l'autorisation de marque et les documents de batterie.
6. Confirmez par écrit si un transit dans un pays tiers de l'UEA est autorisé pour votre expédition; alignez Incoterms, le calendrier de paiement et l'assurance maritime sur le délai de certification.
## Points à retenir d'un devis client jusqu'à confirmation
- Tout pourcentage spécifique de droits d'importation d'EV (conflit de sources; aucune primaire FTS saisie).
- Toute date précise à laquelle une exemption ERA-GLONASS d'importation personnelle a commencé ou pris fin.
- Toute déclaration générale selon laquelle l'acheminement par l'UEA est interdit (ou autorisé).
- Un coût final au débarquement calculé à partir des pourcentages de presse plutôt que du tarif et des tarifs actuels.
## Foire aux questions
**Une EV chinoise a-t-elle besoin d'une homologation de type EAEU?** Oui — les véhicules routiers ordinaires sont dans le champ d'application obligatoire de TR CU 018/2011 (décision de la Commission de l'Union douanière no 877, 2011); choisissez OTTC pour les lots ou SBKTS pour les unités individuelles/utilisées.
**L'ERA-GLONASS est-elle obligatoire?** L'exigence d'appel d'urgence pour les véhicules M/N est inscrite dans TR CU 018/2011; le traitement exact des modifications d'importations individuelles/personnelles par la décision d'application, ainsi confirmer l'exigence actuelle et l'ajustement approuvé avec un organisme accrédité pour votre itinéraire.
**Qu'est-ce que le droit à l'importation des véhicules électriques?** Cet article ne précise pas de pourcentage: les sources de langue russe sont en conflit (taux zéro par rapport à un taux élevé de 2026) et aucune décision primaire FTS/CEE n'a été prise. Classez le HS 8703.80 et confirmez le prix en direct avant le prix.
**What changed on the China side in 2026?** From 1 January 2026 pure-electric passenger vehicles are under an export-licence regime (joint Announcement No. 54), and exporters must qualify under the 2026 MOFCOM application/list process.
**Pourquoi concilier le nom de l'importateur entre les documents?** Pour contrôler les risques, il faut aligner le détenteur de l'OTTC/SBKTS, l'importateur douanier d'enregistrement et le destinataire de la facture pour éviter les différends de dédouanement ou d'enregistrement; lorsqu'ils ne peuvent être identiques, obtenir des directives écrites de l'organisme accrédité ou du courtier en douane sur l'arrangement acceptable.
## Enregistrement d'image
- IMAGE_ASSET_PATH: aucun sécurisé dans le dépôt
- ORIGINAL_IMAGE_URL: non capturé
- SOURCE_PAGE: non capturé
- HÔTEL DE DROITS: NON CONfirmÉ
- LICENSE_OR_USAGE_BASIS: aucune image sécurisée — aucune image de tiers ne peut être publiée jusqu'à ce que les droits soient effacés
- _DATE DE CHERCHE: 2026-09-05
- MODEL_TOPIC_MATCH: doit correspondre au modèle exact/version (ou au sujet du guide) et au marché de référence ci-dessus
- IMAGE_RIGHTS_STATUS: FAIL (aucun actif autorisé capturé; un détenteur de place ou -tain vieille image - Note n'est pas accepté)
- ALAT par langue:
  - **EN**: AutoBridge export-buyer reference — Russia / EAEU EV import approval, vehicle-export procurement guide
  - **FR**: Référence AutoBridge pour acheteurs export — Russia / EAEU EV import approval, guide d’achat à l’export automobile
  - **DE**: AutoBridge-Referenz für Exportkäufer — Russia / EAEU EV import approval, Leitfaden für Fahrzeugexport-Einkauf
  - **ES**: Referencia AutoBridge para compradores de exportación — Russia / EAEU EV import approval, guía de compras para exportación de vehículos
  - **PT**: Referência AutoBridge para compradores de exportação — Russia / EAEU EV import approval, guia de compras para exportação de veículos
  - **JA**: AutoBridge 輸出バイヤー向けリファレンス｜Russia / EAEU EV import approval, 自動車輸出 調達ガイド
  - **KO**: AutoBridge 수출 바이어 참고 자료｜Russia / EAEU EV import approval, 자동차 수출 조달 가이드
  - **VI**: Tài liệu tham khảo AutoBridge cho người mua xuất khẩu — Russia / EAEU EV import approval, hướng dẫn thu mua xuất khẩu xe
  - **TH**: เอกสารอ้างอิง AutoBridge สำหรับผู้ซื้อเพื่อการส่งออก — Russia / EAEU EV import approval, คู่มือจัดซื้อเพื่อการส่งออกยานยนต์
  - **ID**: Referensi AutoBridge untuk pembeli ekspor — Russia / EAEU EV import approval, panduan pengadaan ekspor kendaraan
  - **AR**: مرجع AutoBridge لمشتري التصدير — Russia / EAEU EV import approval, دليل مشتريات تصدير المركبات
  - **ZH**: AutoBridge 出口采购参考｜Russia / EAEU EV import approval, 汽车出口采购指南

## Sources et vérification
| Titre de la source | Organisation | Marché | URL | Vérification | Confiance | Faits corroborés |
|---|---|---|---|---|---|---|
| TR CU 018/2011 règlement consolidé (index; adopté par la décision de la Commission de l'Union douanière n° 877, 09.12.2011) | Registre juridique de l'Union économique eurasienne (**regulateur officiel**) | EAUE | https://regulation.eaeunion.org/ (search "ТР ТС 018/2011" / Decision 877) | 2026-09-03 | **VÉRIFIER** | Champ d'application de la réglementation (L/M/N/O), décision d'adoption, date d'entrée en vigueur, cadre ERA-GLONASS |
| Décision no 877 + TR CU 018/2011 — texte intégral consolidé direct (modifié par 2026) | GARANT (page de document directement susceptible d'examen de la décision officielle) | EAEU/RU | https://base.garant.ru/483421115/ | 2026-09-03 | _CHECTURE | Direct, article-by-article text of Decision 877 / TR CU 018 incl. Annexes et amendements de formulaire OTC |
| 2026 automobile/motorcycle export-licence application notice (商办贸函〔2025〕408号) | MOFCOM (**fonctionnaire du gouvernement**) | NC | https://www.mofcom.gov.cn/zwgk/zcfb/art/2025/art_7c50d6688ca34d1786a1bfd2ccde7d19.html | 2026-09-03 | **VÉRIFIER** | Système/processus d'application 2026, examen local, liste qualifiée |
| Licence d'exportation de passagers Pure-EV (No de publication 54, 2025; de 2026-01-01, HS 8703801090) | MOFCOM / MIIT / GAC / SAMR (**fonctionnaire du gouvernement**) | NC | https://wms.mofcom.gov.cn/zcfb/wmgl/art/2025/art_4fffefa930ec42c1875859eac89ff1e4.html | 2026-09-03 | **VÉRIFIER** | Régime de licence d'exportation de 2026 EV et référence SH |
| 2026 liste d'entreprises de licence d'exportation qualifiée | Ministère du commerce extérieur du MOFCOM (**fonctionnaire du gouvernement**) | NC | http://wms.mofcom.gov.cn/zcfb/wmgl/art/2025/art_6685d244c4f4429e9a749a1a9f34bf19.html | 2026-09-03 | **VÉRIFIER** | Liste des entreprises qualifiées pour l'année en cours |
| Dédouanement des véhicules électriques / SBKTS / EPTS (arrière-plan) | Les points de vente de l'industrie de la langue russe (BATTKA, FindCert; médias) | États | https://findcert.ru/news/rastamozhka-elektromobilya-v-rossii/ | 2026-09-03 | SOURCE UNIQUE | OTT/SBKTS/EPTS processus historique; chiffres de droits NON adoptés (conflit) |
*Note de confiance: la règle de base réglementaire (TR CU 018 / Décision 877) et la règle de la 2026 chinoise en matière de licence d'exportation sont VÉRIFIÉES par des sources gouvernementales ou de réglementation. Les pourcentages de droits d'utilisation, les numéros de TVA/utilisation-frais, les dates de rétablissement de l'ERA-GLONASS pour les importations personnelles et toute règle d'absence de transit n'étaient PAS pris en charge par une source primaire FTS/CEE saisie, les conflits entre les médias et sont délibérément laissés comme éléments de vérification plutôt que comme faits. *
## Révision de la rédaction
- **Auteur / réviseur**: [Équipe de rédaction d'AutoBridge Export](/auteurs/) · méthode selon notre [Politique éditoriale](/politique éditoriale/)
- **Dernière revue**: 2026-09-05
- **Marché de référence**: Russie / EAEU
- **Méthode de vérification**: Sources primaires de réglementation et de gouvernement pour les règles établies; chiffres contradictoires sur les médias retenus plutôt que affirmés; chaque article sensible au temps acheminé à une autorité désignée pour confirmation en direct
- **Norme de rédaction**: Recherches et écrits provenant des sources énumérées ci-dessus (recherches de bureau; aucune conduite directe, démontage ou importation n'est revendiquée). La confiance de la source est affichée par ligne; tout point que nous ne pouvons confirmer indépendamment est présenté comme un élément de vérification plutôt que comme un fait.
#AutoBridge #ExportProcurement #RussiaImport #EAEUTypeApproval #EVCompliance
