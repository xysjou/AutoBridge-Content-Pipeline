# حجز مركبة مُصَدَّرة لتصدير المحيطات: أوراق البضائع الخطرة التي يُحملها ناقل في الواقع
## SEO Metadata
- ** عنوان المنظمة**: وثائق الحجز الخاصة بالصادرات الإلكترونية تحت الرمز IMDG 42-24: UN3556 ورقة عمل مقدمة من شركة ناقلة الشيكات
- ** وصف البيانات**: (أ) كيف تصنف مركبات الليثيوم - البطاريات في شحن المحيطات بموجب التعديل الحالي لشبكة IMDG 42-24 (UN3556/3557/3558)؛ انتهت عملية الانتقال من UN3171 إلى أخرى، الطريق SP961/SP962 UN38.3  and  الأوراق الخاصة بـ (إس دي إس)  and  شروط الحجز الخاصة بالناقلات.
- ** URL المقتطع**: /guides/ev-shipping- un3171-imdg-compliance/
- ** H1 **** مركبات الشحن بالبحر: التصنيف الحالي للبضائع الخطرة، مجموعة وثائق الحجز، الخط الأحمر
- ** كلمة رئيسية**: electric vehicle ocean shipping un3556 imdg 42-24 documents
- ** شروط البحث الثانية**: UN3556 سيارة بطارية ليثيوم UN3557 مركبة معدنية الليثيوم UN3558 سيارة إيون الصوديوم التحول الذي خلفه UN3171  SP961 SP962 vehicle, الصف 9 علامة 9A، UN38.3 موجز اختباري شحنات السيارات الكهربائية ناقلات الاحتياج من طراز EV SOC
- ** مقترحات داخلية بشأن الروابط**: مستوى الشحن إلى un3556-imdg-compliance/؛ - وثائق/وثائق/وثائق/أجزاء سابقة على مانع /مبادئ/ألوحة قبل الشحن/الفحص/الرقائق؛
- ** اقتراحات تتعلق بالنص**: رقم الأمم بياني للعلامات؛ SP961-vs-SP962 decision flow; (أ) سلسلة وثائق الحجز؛ Class 9 label 9A placard
- ** الاقتراحات**: UN3556 IMDG 42-24 - المادة 9 من شحن المركبات الكهربائية؛ "سلسلة وثائق حجز الشحن البحري"
## ابدأ هنا، الحرف الفي كلي هو البضائع الخطرة، ودخل تغير في 42-24
ولا تزال مركبة كهربية سليمة ومصنعة مجهزة ببنائها تشكل سلعا خطرة للنقل البحري. Under **IMDG Code Amendment 42-24 (2024 Edition), إلزامية من 1 يناير 2026 ** تقسم المركبات التي تعمل بالبطارية إلى وحدات مخصصة بدلا من أن تكون تحت رقم بطانية واحد:
- ** UN3556 - مركبات، ليثيوم - أيون - قطط** (قضية بي في أو بي في أو فائقة التليفزيون، التي تُعد بطارية الشق الليثيوم)؛
- ** UN3557 - مركبات، ليثيوم - مطاطي مزود بالطاقة**؛
- ** UN3558 - مركبات صوديوم - مروحة**.
All sit in **Class 9**. The older blanket **UN3171 ("battery-powered vehicle/equipment") sea transition ended on 31 December 2025**; لا تبني 2026 حجز على UN3171 لسيارة الليثيوم بالنسبة لمصفوفة التصنيف الكاملة  and  "الدخلات الخفية (UN3480/UN3481)" انظر دليل المرافقة [يقطع غطاء تحت IMDG 42-24: (أ) مصفوفة إلى un3556-imdg-compliance/)؛ وتركز هذه الصفحة على ما يحتاجه الطلب في الحجز وما يجعل ملفاً قابلاً للحجز**.
## ألعاب الفهد الجامعتين: SP961 ضد SP962
ويقود هذا الحكم الخاص كلا من الملاجئ والأوراق:
- ** ينطبق مبلغ SP961 ** على الحالات التي يتم فيها تحميل المركبة أو تطهيرها أو معالجتها أو تفريغها تحت سلطتها** (مسار رو رو رو - سيل الذي تحركه بنفسها) ويفي بالشروط المعلنة؛ ويحمل لإغاثة محددة.
- ** SP962 ** ينطبق على المسار الذي لا يحرك نفسه**، ويعامل على أنه من الفئة الكاملة 9: (أ) إعلان عن السلع الغامضة**، ** فئة الماشية A** الاحتياجات من التدريب  and  the **Class 9 label 9A** marking route apply.
ويقرر المسار الذي تسيرون عليه بمعرفة ما إذا كانت الوحدة تتحرك فعلا**، وليس بالأفضلية - لا يمكن للسيارة التي يخطط لها تصدير الحاويات أن تطالب بالإغاثة التي تحركها ذاتيا.
## The Document Set a Booking Rests on
1. **UN38.3 test summary report** covering **both the cells  and  )أ(حزمة - تقرير خليوي فقط غير كاف للمجموعة؛ لاحظوا التنقيح الحالي الذي يقبله ناقلكم
2. **S/MSDS (GHS)**، مع تحديد الدخول غير الصحيح للأمم المتحدة (UN3556 لمركبة الليثيوم)، والفئة 9، والجدول الزمني للإم إس** - استكمال أي وثيقة قديمة لا تزال تُسمي سوى UN3171.
3. ** استمارات إعلان السلع الخطرة وحجز الناقل**، مكتملة إلى معيار 42-24 ** (المطلوبة على الطريق SP962).
4. ** القرار المُركَّز ضد قرار غير مُتخذ/مُنحَّى*. وتتحرك بطاريات السكك الحديدية أو الليثيوم المطلة تحت ** UN3480/UN3481 **، وليس UN3556، وتحتاج إلى طريقها الخاص (بما في ذلك شهادة تعبئة البضائع الخطرة عند الاقتضاء). الإغاثة الشاملة لم تغطي أبداً قطع الغيار المُحزمة جنباً إلى جنب
5. ** الوحدات التي تم تدميرها أو تنفيذها أو استشهادها** هي حالة منفصلة: وهي تتطلب ** موافقة ناقلات**، لا يمكن في كثير من الأحيان أن تمضي على شروط عادية، ولا يجب أبدا أن تُعاد صياغتها على أنها شحنة عادية تبلغ UN3556 شحنة.
## Version and Timeliness (state these on every file)
- تعديل مُسبق: ** IMDG ** 42-24 (2024 Edition)، إلزامي من 2026-01-01 **، ذكر التعديل على الحجز بدلاً من افتراض نموذج الناقل القديم.
- ** UN38.3 تنقيح:** يؤكد التنقيح الذي تقبله خطكم ووجهتكم (مع مراعاة الوقت).
- ** متطلبات النقل من جانب الصين لليثيوم** تؤكد النص الرسمي الحالي وكيف ينطبق على المركبات التي تعمل بالوقود مقابل البطاريات المطلية** بدلا من اقتباس المادة المتعلقة بالامتثال التي تبلغ 2025 كقانون مستقر.
## ناقل - سابتشي لاير (الرمز هو الطابق، لا السقف أبدا)
Named carriers publish their own 42-24 advisories — for example **Maersk's customer advisory on Amendment 42-24** confirms the 2026-01-01 applicability, الـ UN3556  and  تغيير الـSP962 بطاقه فوق القانون، الخطوط العامة، لكل مسافر ومحطة طرفية**:
- (أ) الحد الأقصى للتكلفة**، والأدلة على حالة نظام السحب البالغ 12؛
- (أ) ما إذا كانت الوحدة تتحرك ** رو رو رو (محركة ذاتياً) أو في حاوية فقط**، و ** شروط القبول المحددة**؛
- : رصد إطلاق بقطع الأرض، وإلغاء الحظر بالحظر على القتال**.
هذه هي "الشاحنات" و "الطرق" و "الحساسية" و "الزمن" و "الزمن" و "الإنترنت" و "الجوود" الحالية للناقل" مكتوبة لـ "الزوجين" الدقيقين قبل أن يبشروا بالإبحار
## ما يوصي به هذا الدليل لك إعداد قبل الحجز
- Cell **and**pack UN38.3 (accepted revision) plus an SDS naming ** UN3556 class 9 EmS**, with any legacy UN3171 paperwork refreshed.
- قرار مكتوب ** SP961 (مدفوع ذاتيا) ضد SP962 (محتوى)** يطابق الحركة الفعلية؛ وDGD وعلامة الـ 9A جاهزين لـ SP962.
- A clear **installed vs loose battery** split, with the separate UN3480/UN3481 route for spares.
- "الناقل الملون" الحالي "الـ "س.أ.م.ت"/الـمـوجات/الطـريـق" "لـزوج المرفـئ المعيـن "موافقـة قبل التوصيل
- A **damage/defect screen** (no warning lights, no impact/flood/recall history) fed into the PSI - see the pre-shipment inspection guide.
## الأسئلة المتكررة
** ما رقم الأمم المتحدة هو سيارة كهربائية من الليثيوم يون مشحنة تحت الآن؟** تحت IMDG 42-24 (mandatory 2026-01-01) It is ** UN3556 ** (lith-ion-battery-powered vehicle), Class 9; UN3557 هو الليثيوم - المولد و UN3558 صوديوم -يون. The old blanket UN3171 sea transition ended 31 December 2025.
** ما الفرق بين SP961 وSP962؟** SP961 يغطي مسار مناولة ذاتية المالكة مع عمليات الإغاثة المحددة؛ ويغطي SP962 طريق ذاتية، حيث يبلغ طولها 9 (DGD، والغطاء ألف، والعلامة 9A، والتدريب). والحركة الفعلية تقرر ما ينطبق.
** هل يحتاج جهاز الأشعة إلى عبوة بضائع خطرة؟** ولا تُقيد المركبة الكاملة والصحيحة مثل الخلايا غير المستقرة، وإنما على طريق المراجعة الخاصة المعمول به؛ وتُتبع البطاريات UN3480/UN3481 مع عبوات ووثائق خاصة بها.
** هل يوجد تقرير على مستوى الخلية يبلغ UN38.3 بما فيه الكفاية؟** لا - يجب تغطية كل من الخلايا والحزمة/الوحدة.
** هل يمكن أن تكون سفينة متضررة أو مُذكّرة بالطائرة في العادة**؟ لا - الوحدات التي تحتاج إلى موافقة صريحة من الناقل، وكثيرا ما ترفض؛ never disguise one as a standard UN3556 shipment.
## سجل الصور
- لم يُؤمن أي منها في مستودع
- ORIGINAL: IMAGE_URL: not captured
- SOURCE_PAGE: not captured
- SOURCE_FILE_PAGE: not applicable - no candidate media file identified (no licence to assert)
- الحقوق - حقوق غير مؤكدة
- LICENSE_OR_USAGE_BASIS: لا يوجد مضمون - لا يمكن نشر أي صورة لأطراف ثالثة إلى أن تُبرأ الحقوق
- CHECKED_DATE: 2026-09-06
- MODEL_TOPIC_MATCH: must match the exact model/version (or the guide topic) and reference market above
- IMAGE_SCOPE_NOTE: match the exact model family/topic only; must not imply a specific trim/model-year, real VIN, in-person inspection or actual transaction
- IMAGE_Rights_STATUS: FAIL (لا توجد أصول مرخصة مقبوض عليها؛ ولا تقبل مذكرة " تحمل صورة قديمة ")
- BLOCK REASON: ولا يمكن تأمين أي صورة قابلة لإعادة الاستخدام: فعمليات غير قابلة للتواصل من بيئة البحوث، وتحتاج مكتبات الأوراق المالية إلى إمكانية الوصول إلى نظام المعلومات وصورة موقع مكتبة الأوراق المالية ليست منحة تجارية لإعادة الاستخدام؛ ولا توجد صورة مملوكة للشركة. ابقوا في القوات المسلحة بدلا من التأكيد.
- ALT by language:
  - **EN**: AutoBridge export-buyer reference — Shipping an electric vehicle by sea (IMDG), vehicle-export procurement guide
  - **FR**: Référence AutoBridge pour acheteurs export — Shipping an electric vehicle by sea (IMDG), guide d’achat à l’export automobile
  - **DE**: AutoBridge-Referenz für Exportkäufer — Shipping an electric vehicle by sea (IMDG), Leitfaden für Fahrzeugexport-Einkauf
  - **ES**: Referencia AutoBridge para compradores de exportación — Shipping an electric vehicle by sea (IMDG), guía de compras para exportación de vehículos
  - **PT**: Referência AutoBridge para compradores de exportação — Shipping an electric vehicle by sea (IMDG), guia de compras para exportação de veículos
  - **JA**: AutoBridge 輸出バイヤー向けリファレンス｜Shipping an electric vehicle by sea (IMDG), 自動車輸出 調達ガイド
  - **KO**: AutoBridge 수출 바이어 참고 자료｜Shipping an electric vehicle by sea (IMDG), 자동차 수출 조달 가이드
  - **VI**: Tài liệu tham khảo AutoBridge cho người mua xuất khẩu — Shipping an electric vehicle by sea (IMDG), hướng dẫn thu mua xuất khẩu xe
  - **TH**: เอกสารอ้างอิง AutoBridge สำหรับผู้ซื้อเพื่อการส่งออก — Shipping an electric vehicle by sea (IMDG), คู่มือจัดซื้อเพื่อการส่งออกยานยนต์
  - **ID**: Referensi AutoBridge untuk pembeli ekspor — Shipping an electric vehicle by sea (IMDG), panduan pengadaan ekspor kendaraan
  - **AR**: مرجع AutoBridge لمشتري التصدير — Shipping an electric vehicle by sea (IMDG), دليل مشتريات تصدير المركبات
  - **ZH**: AutoBridge 出口采购参考｜Shipping an electric vehicle by sea (IMDG), 汽车出口采购指南

## المصدر: التحقق
| عنوان المصدر | المنظمة | السوق | URL | تم التحقق منها | الثقة | الوقائع الداعمة |
|---|---|---|---|---|---|---|
| IMDG Code (2024 Edition incl. Amendment 42-24), official publication page | المنظمة البحرية الدولية | Global | https://www.imo.org/en/publications/pages/imdg%20code.aspx | 2026-09-05 | مفقود | الحالي والتاريخ الإلزامي؛ إطار الفئة 9 |
| مستشار العملاء - التغييرات التنظيمية  IMDG Code Amendment 42-24 | مارزك (يسمى حاملة المحيط) | Global | https://www.maersk.com.cn/~/media_sc9/maersk/local-information/files/asia-pacific/japan/export/advisory---others-and-document/maersk-customer-advisory-regulatory-changes-imdg-code-amendment-42-24-japanese.pdf | 2026-09-05 | صرخات | الناقل: قابلية الانطباق من 2026-01-01؛ UN3556 بند؛ SP962 |
| Guidance — UN3556 (ADR/RID 2025, IMDG Amdt 42-24: التصنيف، SP388/666/961/962، UN38.3 | Säkerhets Rådgivarna (DG safety adviser) | Global | https://sakerhetsradgivarna.se/farligt-gods/guide/un-3556-adr-rid-imdg | 2026-09-05 | صرخات | UN3556 صنف 9/label 9A؛ UN3171 عملية انتقال بحري إلى 2025-12-31؛ SP961 مسارا ذاتيا مقابل SP962 مسار للحاويات |
| مركبات الشحن بموجب تعديل IMDG 42-24 (الكتاب): UN3556/3557/3558 مقابل الإرث UN3171 | IMDG Code Compliance Centre Shashi Kallada | Global | https://shashikallada.com/wp-content/uploads/2026/07/Ebook-Shipping-Vehicles-Under-IMDG-Code-Amendment-42-24.pdf | 2026-09-05 | صرخات | UN3557 ليثيوم - ميتال و UN3558 من القيدات الصوديومية - أيون؛ التمييز من UN3171 |
| البضائع الخطرة على الصين الطرق 2026: IMDG booking checklist | Shenzhen Top Way International المستقبل | CN-UAE route | https://www.topwayshipping.com/dangerous-goods-on-china-uae-routes-2026-imdg-compliance-checklist-before-you-load/ | 2026-09-05 | SINGLE OURCE | تطبيق نظام الحجز على وفحص خاصة بالناقلات (ملوث، وليس عالميا) |
| وثائق تصدير الليثيوم - البطاريات (UN38.3/SDS/packaging قرطا) | Dingzhou News | CN | https://www.dzxww.cn/article/293251787800392.shtml | 2026-09-03 | SINGLE OURCE | UN38.3 زنزانة + حقيبة، SDS، غير مثبتة |
| مخاطر جمركية تصدير الطاقة الجديدة (قاعدة الليثيوم الصينية 2025) | تحليل الامتثال في سوهو | CN | https://m.sohu.com/a/1025837015_100159475/ | 2026-09-03 | SINGLE OURCE | اشتراط نقل الليثيوم من جانب الصين (المصدر الرئيسي؛ تأكيد النص الرسمي) |
* ملاحظة: التعديل الحالي، و UN3556/3557/3558 هيكل منقسم و SP961/SP962 مركبان مركبتان إلى منشور المنظمة البحرية الدولية و 42-24 من المواد شركة دي جي؛ ومستويات شركة النقل SOC، والقبول النهائي، وتطبيق القواعد من جانب الصين هي تطبيقات خاصة ومراعية للوقت - تؤكد المصطلحات الحالية للناقل والنص الرسمي لكل حجز. ♪
## استعراض التحرير
- ** [فريق تحرير تصدير أوتو بريدج] (/مؤلف/) - طريقة لكل [سياستنا الانتخابية]
- ** لم يُستعرض بعد**: 2026-09-05
- ** سوق الامتثال العالمي للوسائل الخطرة للمحيطات، وهو النظام الحالي للإدارة المتكاملة لنظم المعلومات البيئية 42-24؛ وعمّت قاعدة الجانب الصيني بشكل منفصل؛ وذُكرت شروط الناقلة وخط سيرها
- ** طريقة التأهيل**: منشور المنظمة البحرية الدولية الابتدائية + فرز استشاري مسموع + امتحان تخصصي للدبغ؛ الأصناف الحساسة من حيث الوقت والمحددة بالناقلات؛ دليل التصنيف المصاحب متصل بتجنب الأكل
- ** المعيار الإفريقي**: باحثة ومحررة من المصادر المذكورة أعلاه (بحوث مكتبية؛ ولا يُدَّعى عن أي قيادة مباشرة أو تمزق أو استيراد). وتظهر الثقة في المصدر في الصف الواحد؛ وأي نقطة لا يمكننا تأكيدها بشكل مستقل تعرض كبند تحقق بدلا من التأكيد على أنها حقيقة.
- ** الشفافية**: استُخدمت الصياغة المدعومة من منظمة العفو الدولية. وتستند هذه المادة إلى البحوث المكتبية وآلية الجودة. ولا يُزعم إجراء أي اختبار مباشر إلا إذا تم توثيقه بشكل صريح؛ ويؤكد متطلبات مراعية للوقت ومحددة للمقصد قبل التحول.
#AutoBridge #EVShipping #IMDG4224 #UN3556 #ExportCompliance
