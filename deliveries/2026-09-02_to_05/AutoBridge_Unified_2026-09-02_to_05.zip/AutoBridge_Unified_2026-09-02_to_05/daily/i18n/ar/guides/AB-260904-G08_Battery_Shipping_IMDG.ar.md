# Shipping an Electric Vehicle by Sea Under IMDG 42-24: UN3556, UN3171 and the Spare-Battery Distinction

## SEO Metadata
- ** عنوان المنظمة**: الشحن البحري في البحر تحت العنوان IMDG 42-24 - UN3556/3557/3558 مقابل UN3480/3481
- ** وصف البيانات**: من 2026 مركبة من الليثيوم -يون رُكبت بسفينة بطارية تبلغ UN3556 (المتر الليثيوم UN3557، صوديوم - UN3558) بموجب تعديل IMDG 42-24؛ و UN3171 مركبة ضيقة وطائرة غير مطلية تستخدم UN3480/3481 بطاريات تبلغ UN38.3.
- ** URL المقتطع**: /guides/ev-shipping- un3556-imdg-compliance
- ** H1 **** تصنيف مركبة تحمل بطاقات البطارية لشحن المحيطات بموجب مدونة قواعد التعريفات الجمركية الحالية (التعديل 42-24)
- ** كلمة مفتاحية برية**: UN3556 مركبة إيون من طراز IMDG 42-24
- ** شروط البحث الثانية**: UN3557 مركبة معدنية الليثيوم UN3558 سيارة إيون الصوديوم P912 أمر حزم SP405 علامة، تضييق UN3171 UN3480 UN3481  UN38.3 manual of tests rev8
- ** مقترحات داخلية بشأن الربط**: - تصدير - قبل الشحن؛ وثائق المركبات/المركبات/مركبة
- ** اقتراحات رمزية**: حاشية كاملة مقابل عدد غير مقصود من الأمم المتحدة؛ صف من 9 بطاقة؛ P912/SP405 علامة رسم بياني
- ** الاقتراحات**: "UN3556 مركبة مركبه مقابل UN3480 بطارية طليقة تحت IMDG 42-24"

## التصنيف المتغير - الـ UN3171 القديمة هي الآن خاطئة
ومن الممارسات المشتركة التي جرت قبل 2026 حجز أي مركبة مدفوعة بالبطارية تحت UN3171 **. بموجب قانون (آي.دي.جي) الإجباري  Amendment 42-24** (adopted by IMO Resolution **MSC.556(108)**  and  ** إلزامية في الصين من 2026-01-01 ** لكل نص رسمي لإدارة السلامة البحرية في الصين، لم يعد ذلك صحيحا بالنسبة لمركبات الليثيوم الرئيسية. استخدام الرقم القديم في إعلان 2026 هو خطأ تصنيفي يوقف العمل الورقي للوقود الخطرة في الحجز

## مركبة كاملة (مركبة) UN3556 UN3557 UN3558
بالنسبة لجهاز متنقل مع بطاريته المثبتة**:
- **UN3556 — lithium-ion-battery-powered vehicle**
- **UN3557 — lithium-metal-battery-powered vehicle**
- **UN3558 — sodium-ion-battery-powered vehicle**

وتنظم التعليمات الجديدة التي تتضمن مجموعة من المواد التي تُصدرها P912 **، توفير المياه وتأمين هذه القيود. وعندما لا تكون المركبة المحملة بـ UN3556 مقفلة بالكامل** عن طريق التغليف أو الصندوق ** يحدد الاعتماد الخاص البالغ SP405 ** متطلبات الوسم. *** تم تضييق نطاق الإرث ** UN3171 ** على التي تبثها البطاريات الصالحة للشرب، أو البطاريات الصوديومية أو السوديوم - السواحل**؛ ويجب إعلان مركبات الليثيوم الرئيسية دون UN3171 من 2026. هذه هي المادة 9 الدخول، الوثائق تتبع رسالة IMDG 42-24 و طبقة الناقلة المُحتسبة الإضافية.

## "البعثة" "البعثرة" "مختلفة"
لا تخلط بين رقم المروحية بأكمله و الخلايا و الأحزمة
- ** UN3480 - بطاريات الليثيوم -يون مُنَقَّلة لوحدها** (اللو/المساحة).
- ** UN3481 - بطاريات الليثيوم - أيون معبأة أو متضمنة في معدات**.
البطاريات المطلية الصوديوم تحمل أرقامها الخاصة A spare service pack therefore ships under the **UN3480/3481** family — never by reusing the vehicle's UN3556.

## UN38.3 ودليل الاختبارات والمعايير
قبل النقل الليثيوم)اللقب/اليون(-  and  الآن صوديوم - يجب أن تستكمل البطاريات الاختبارات **** 1–T.8 تحت الباب 38.3 ** من برنامج الأمم المتحدة للاختبارات  and  المعايير*  current edition **Revision 8 (2023) with Amendment 1** (Rev.8 brought sodium-ion batteries within 38.3),  and  تحمل ملخصاً **. بالنسبة لسيارة كاملة، هذه الأدلة تُثبت عند مستوى بالنسبة للبطاريات الاحتياطية التي تقل عن UN3480/3481، هو شرط الشحن المباشر. The US 49 CFR §173.185 likewise incorporates UN38.3 by statutory reference, illustrating how widely the Section 38.3 test summary is expected.

## حالة الشحن وناقل لاير
ويحدد النص الخاص بالشركة الدولية للتنمية المتكاملة للحد من مثل نسبة مئوية ثابتة ** من الشحن**، ويضعه كل ناقل**، على رأسه**. هذه الصفحة تقول لا يوجد نسبة ثابتة من شركة SOC بدون أساس رسمي**؛ الحصول على رحلة خطية لحامض نووي مكتوبة بواسطة رحلة (الشاحنات قد تفرض شروطاً أكثر صرامة من الحد الأدنى لـ IMDG). وتأتي قواعد الضارّة أيضاً بعد اعتماد المدونة الحالية والناقلات، ولا تُعمم هنا.

## قائمة مرجعية بالحجز
1. (أ) الكيمياء المشددة (ليثيوم -يون/ليثيوم - -يون/مبتل)  select اختيار UN3556/3557/3558 (أو الـ UN3171 الضيقة فقط حيثما ينطبق ذلك حقاً).
2. يتم تلفيق البطارية بالتسليم** (قيد المركبات) ضد**([UN3480/3481]).
3. تطبيق البند P912 **؛ تطبيق الرمز ** SP405 **، إذا لم يكن مرفقا بالكامل.
4. المجموع ** UN38.3 (Rev. 8+Amd.1) T. 1–T.8اختبارات** للبطارية.
5. الحصول على تعليمات الـ دي سي  and  الوثائق من الرتبة 9  and  تَلوّجُ.

## حدود هذا الدليل
- لا توجد نسبة مئوية ثابتة أو حد للكميات دون أساس رسمي.
- No reuse of UN3171 for lithium vehicles under the current Code.
- وتُعد متطلبات النقل الأكثر صرامة خاصة بشركات النقل الخاصة برحلات محددة.

## الأسئلة المتكررة
** ما هو رقم الأمم المتحدة هو EV الليثيوم - أيون مشحن بالبطارية المركب؟** UN3556 بموجب تعديل IMDG 42-24 (Lthium-metal UN3557، الصوديوم - أي UN3558).
** هل يمكنني أن أستخدم UN3171؟ ** فقط من أجل تضييق نطاق الصوديومية أو الطينية؛ وليس من أجل مركبات الليثيوم الرئيسية من 2026.
** ماذا عن بطارية إضافية في نفس الحاوية**؟ تستخدم بطاريات الليثيوم اللووز UN3480 (أو UN3481 إذا كانت محزمة مع المعدات أو محتوية عليها) وليس UN3556.
** أي عدد من الحالات ينطبق على عدد UN38.3؟** الدليل الحالي للاختبارات  and  المعايير، Rev. 8 with Amendment 1, اختبارات "تي 1–T.8" مع موجز اختبار

## سجل الصور
- لم يُؤمن أي منها في مستودع
- ORIGINAL: IMAGE_URL: not captured
- SOURCE_PAGE: not captured
- SOURCE_FILE_PAGE: not applicable - no candidate media file identified (no licence to assert)
- الحقوق - حقوق غير مؤكدة
- LICENSE_OR_USAGE_BASIS: لا يوجد مضمون - لا يمكن نشر أي صورة لأطراف ثالثة إلى أن تُبرأ الحقوق
- CHECKED_DATE: 2026-09-06
- MODEL_TOPIC_MATCH: must match the exact model/version (or the guide topic) and reference market above
- IMAGE_SCOPE_NOTE: match the exact model family/topic only; must not imply a specific trim/model-year, real VIN, in-person inspection or actual transaction
- IMAGE_Rights_STATUS: FAIL (لا توجد أصول مرخصة مقبوض عليها؛ ولا تقبل مذكرة " تحمل صورة قديمة ")
- BLOCK REASON: ولا يمكن تأمين أي صورة قابلة لإعادة الاستخدام: فعمليات غير قابلة للتواصل من بيئة البحوث، وتحتاج مكتبات الأوراق المالية إلى إمكانية الوصول إلى نظام المعلومات وصورة موقع مكتبة الأوراق المالية ليست منحة تجارية لإعادة الاستخدام؛ ولا توجد صورة مملوكة للشركة. ابقوا في القوات المسلحة بدلا من التأكيد.
- ALT by language:
  - **EN**: AutoBridge export-buyer reference — EV shipping under IMDG 42-24 UN3556, vehicle-export procurement guide
  - **FR**: Référence AutoBridge pour acheteurs export — EV shipping under IMDG 42-24 UN3556, guide d’achat à l’export automobile
  - **DE**: AutoBridge-Referenz für Exportkäufer — EV shipping under IMDG 42-24 UN3556, Leitfaden für Fahrzeugexport-Einkauf
  - **ES**: Referencia AutoBridge para compradores de exportación — EV shipping under IMDG 42-24 UN3556, guía de compras para exportación de vehículos
  - **PT**: Referência AutoBridge para compradores de exportação — EV shipping under IMDG 42-24 UN3556, guia de compras para exportação de veículos
  - **JA**: AutoBridge 輸出バイヤー向けリファレンス｜EV shipping under IMDG 42-24 UN3556, 自動車輸出 調達ガイド
  - **KO**: AutoBridge 수출 바이어 참고 자료｜EV shipping under IMDG 42-24 UN3556, 자동차 수출 조달 가이드
  - **VI**: Tài liệu tham khảo AutoBridge cho người mua xuất khẩu — EV shipping under IMDG 42-24 UN3556, hướng dẫn thu mua xuất khẩu xe
  - **TH**: เอกสารอ้างอิง AutoBridge สำหรับผู้ซื้อเพื่อการส่งออก — EV shipping under IMDG 42-24 UN3556, คู่มือจัดซื้อเพื่อการส่งออกยานยนต์
  - **ID**: Referensi AutoBridge untuk pembeli ekspor — EV shipping under IMDG 42-24 UN3556, panduan pengadaan ekspor kendaraan
  - **AR**: مرجع AutoBridge لمشتري التصدير — EV shipping under IMDG 42-24 UN3556, دليل مشتريات تصدير المركبات
  - **ZH**: AutoBridge 出口采购参考｜EV shipping under IMDG 42-24 UN3556, 汽车出口采购指南

## المصدر: التحقق
| عنوان المصدر | المنظمة | السوق | URL | تم التحقق منها | الثقة | الوقائع الداعمة |
|---|---|---|---|---|---|---|
| تعديل قانون إدارة الشؤون الإدارية 42-24 النص الصيني الرسمي PDF | إدارة السلامة البحرية الصينية | INTL/CN enforcement | https://www.msa.gov.cn/public/documents/document/mdiw/mjqw/~edisp/20251201020240683.pdf | 2026-09-04 | مثقفة)بالمرتبة الأولى( | 42-24، MSC. 556 (108) و 2026-01-01، و UN3556-3558، و P912، و 9 |
| دليل الأمم المتحدة للاختبارات والمعايير (التنقيح 8 + التعديل 1) الفرع 38.3 (SCETDG- 66 INF. 30) | UNECE UN Sub-Committee | INTL | https://unece.org/sites/default/files/2025-06/UN-SCETDG-66-INF30e.pdf | 2026-09-04 | مثقفة)بالمرتبة الأولى( | Rev. 8+Amd.1,  UN38.3 T.1–T.8, الصوديوم -يون |
| UN/SCETDG- 64 INF. 29 lithium-battery identification 38.3 marking amendment | UNECE | INTL | https://www.unece.org/sites/default/files/2024-06/UN-SCETDG-64-INF29e.pdf | 2026-09-04 | مثقفة)بالمرتبة الأولى( | 38.3 تعديل |
| US 49 CFR § 173.185 (incorporates UN38.3 by IBR) | US GovInfo (CFR) | الولايات المتحدة الأمريكية | https://www.govinfo.gov/content/pkg/CFR-2024-title49-vol2/xml/CFR-2024-title49-vol2-sec173-185.xml | 2026-09-04 | مثقفة)بالمرتبة الأولى( | UN3480/3481، المرجع القانوني UN38.3 |
| الترجمة الشفوية IMDG 42-24 (MSC. 556 (108) ، تاريخ النفاذ) | البحرية (المؤقتة) | INTL/CN | http://m.toutiao.com/group/7585883173825921546/ | 2026-09-04 | صرخات (الدعم) | التفسير المستكمل |
| UN3556 SP405 من الترجمة الشفوية | أخبار جيوبي (النشرة) | INTL | http://m.toutiao.com/group/7598735209990734370/ | 2026-09-04 | SINGLE -SOURCE (supporting) | SP405 علامة |
* ملاحظة توضيحية: التصنيف الأساسي المرتكز إلى نظام تقييم الأداء (IMDG 42-24) ودائرة الأمم المتحدة الاقتصادية لأوروبا (مانالتنقيح مانويل 8+Amd.1، 49 CFR) المصدر الرئيسي؛ ولا تدعم صفحات وسائط إلا، ولا تزال الأدلة الرئيسية على أعداد الأمم المتحدة، أو ما زالت هناك UN38.3. قيم ثابتة لمراكز البحث العلمي. ♪

## استعراض التحرير
- ** Author**: AutoBridge Export Editorial Team; method per our [Editorial Policy](/editorial-policy/)
- ** لم يُستعرض بعد**: 2026-09-05
- ** سوق الإحالة**: International IMDG (42-24) with China enforcement date
- ** طريقة التحقق**: بدل الإقامة اليومي + دليل لجنة الأمم المتحدة الاقتصادية المتحدة + 49 CFR primary sources; loose vs installed battery separated; no unsupported SOC number
- ** الشفافية**: استُخدمت الصياغة المدعومة من منظمة العفو الدولية. وتستند هذه المادة إلى البحوث المكتبية وآلية الجودة. ولا يُزعم إجراء أي اختبار مباشر إلا إذا تم توثيقه بشكل صريح؛ ويؤكد متطلبات مراعية للوقت ومحددة للمقصد قبل التحول.
- ** المعيار الإفريقي**: باحثة ومحررة من المصادر المذكورة أعلاه (بحوث مكتبية؛ ولا يُدَّعى عن أي قيادة مباشرة أو تمزق أو استيراد). وتظهر الثقة في المصدر في الصف الواحد؛ وأي نقطة لا يمكننا تأكيدها بشكل مستقل تعرض كبند تحقق بدلا من التأكيد على أنها حقيقة.

**Tags**: #IMDG4224 #UN3556 #UN383 #EVShipping #DangerousGoods
