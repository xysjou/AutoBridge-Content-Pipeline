# Lesen eines Seefracht-Quotations für den Fahrzeugexport: Ladestruktur ohne erfundene Zahlen

## SEO Metadaten
- **SEO-Titel**: Ocean Freight Charge Structure for Vehicle Export — O/F, THC, DOC, BAF erklärt
- **Meta Description**: Verstehen Sie O / F, THC, DOC / SEAL / VGM, BAF und Zuschläge, Herkunfts- und Zielgebühren und warum AMS / ACI / ENS Manifestgebühren routenspezifisch sind - ein Strukturleitfaden, der bewusst keine festen Beträge angibt.
- **Vorgeschlagene URL**: /guides/ocean-freight-charge-structure-vehicle-export
- ** H1 **: Dekodierung eines Fahrzeug-Exportfracht-Angebots: Welche Gebühren existieren, wer sie berechnet und was zu überprüfen ist
- ** Primäres Keyword**: Export von Seefrachtgebührenstrukturfahrzeugen THC DOC BAF
- **Secondary Search Terms**: O/F-Seefracht, Terminalumschlagsgebühr, DOC-Dokumentengebühr, SEAL VGM-Gebühr, BAF EBS-Zuschlag, AMS ACI ENS-Manifestgebühr, Herkunfts-/Zielgebühren
- **Interne Linkvorschläge**: /guides/vehicle-export-bill-of-lading-types/; /guides/vehicle-export-pdi-pre-shipment-handover/; /guides/vehicle-export-hs-code-classification/
- **Bildvorschläge**: Ladung Wasserfall Ursprung → Ozean → Ziel; Zuschlag Taxonomie; Quote-line-Auditbogen
- **ALT Suggestions**: "Ocean cargo charge structure split by origin, ocean and destination"

## Warum ein strukturiertes Zitat wichtiger ist als eine niedrige Zahl
Eine Headline-Frachtrate gewinnt Buchungen und verliert Geld am Zielort. Fahrzeugexporteure werden nicht von der Basis-Seefracht erwischt, sondern von dem Stapel von Zuschlägen und Zielgebühren, die damit verbunden sind. Dieser Leitfaden erklärt **was jede Ladung ist, was sie in Rechnung gestellt wird und wo sie entsteht ** und - weil sich jede Rate mit Spur, Kapazität und Saison bewegt - gibt es keine festen Beträge ** an. Verwenden Sie es, um ein Angebot Zeile für Zeile zu prüfen, nicht um eine Landekosten zu schätzen.

## Die Bausteine
| Gebühr | Was es abdeckt | In Rechnung gestellt, wo |
|---|---|---|
| **O/F (Ozean Freight)** | Basisseefracht; Hauptbestandteil des Angebots, schwimmend mit Fahrspur/Kapazität/Saison | Ozeanbein |
| **THC (Terminal Handling Charge)** | Terminal Heben/Handling/Lagerung; unterscheidet sich durch Containergröße | Herkunft **und Bestimmungsort (OTHC/DTHC) |
| **DOC (Dokumentengebühr)** | Dokumentation; Ursprungs-ODOC und Bestimmungsort-DDOC sind getrennt | Beide Enden |
| **SELBST/VGM** | Siegelgebühr und geprüfte Bruttomassenwägungsgebühr — Waren des gemeinsamen Ursprungs | Ursprung |
| **BAF (Bunkeranpassung; ähnlich wie EBS)** | Kraftstoffgebundene Zuschläge; neben CAF (Währung), PSS (Spitzensaison), PCS (Überlastung), WRS (Kriegsrisiko) | Ozean/variabel |

## Manifest Einreichungsgebühren sind Route-Spezifisch (redaktionelle Anleitung, keine universelle Gebühr)
**AMS, ACI, ENS** und ähnliche automatisierte Manifest-Anmeldegebühren fallen in der Regel ** nur an, wenn das Routing durch die entsprechende obligatorische Anmelderegion ** (z. B. US / Kanada / EU-Vorabmanifestierungsregime) verläuft. Ob eine Gebühr erhoben wird, hängt von der ** Lane und dem Spediteur ** ab und wird auf der Rechnung dieser Sendung abgerechnet. Dies ist eine **routenspezifische Anleitung**, kein universeller internationaler Gebührenplan: Eine Spur, die diese Regimes nie berührt, sollte die Gebühr nicht tragen, und der Führer behauptet keinen festen Tarif dafür.

## Herkunft vs. Bestimmungsort - Wo Streitigkeiten Hüllen
- Teilen Sie jede Zeile in **Ursprungsgebühren** (vor/bei der Verladung) und **Zielgebühren** (bei der Entladung/Sammlung). Fahrzeugkäufer sind am häufigsten überrascht von Ziel-THC, DDOC und Lieferaufträgen, die sie nicht erwartet haben.
- Bitten Sie den Spediteur, jede Zeile und ihre Abrechnungseinheit (pro Container / pro Rechnung / pro Fahrzeug) zu benennen, damit zwei Zitate auf derselben Basis verglichen werden können.
- Achten Sie auf **ungenannte Zuschläge ** und "lokale Gebühren" ohne Einheit - hier wird eine niedrige Headline-Rate zurückgewonnen.

## Eine Quote-Audit-Methode (keine Zahlen)
1. Bestätigen Sie Incoterm und welche Seite Herkunft vs. Zielkosten trägt.
2. Liste O/F und jeden Zuschlag mit seinem **Namen und der Abrechnungseinheit **.
3. Markierung einer beliebigen AMS/ACI/ENS-Linie und Vergleich mit dem **tatsächlichen Routing** (routenspezifisch).
4. Abgleich der Ursprungs- und Bestimmungsspalten; schriftliche Erhebung von Bestimmungsgebühren.
5. Re-Quote bei der Buchung - alle Preise sind zeitsensibel und das formelle Angebot zu diesem Zeitpunkt gilt.

## Was dieser Guide nicht tun wird
- **Keine festen Mengen** (keine RMB THC-Bereiche, keine Anmeldegebührennummern): Die vorherigen Zahlen sind veraltet oder marktvariabel und werden nie als aktuell dargestellt.
- **Es wird keine Landed-Cost- oder Margin-Schätzung** für AutoBridge oder den Käufer abgeleitet; dies erfordert ein offizielles Live-Angebot.

## Häufig gestellte Fragen
**Warum unterscheiden sich zwei "gleiche Rate" -Quotes am Zielort? ** Normalerweise unterscheiden sich die Bestimmungs-THC/DDOC/Liefergebühren und die Zuschlagsbezeichnung — vergleichen Sie Zeile für Zeile mit Abrechnungseinheiten.
**Muss jede Sendung AMS / ACI / ENS bezahlen? ** Nein — diese Manifestgebühren entstehen nur, wenn die Strecke durch die betreffende obligatorische Einlegeregion führt; überprüfen Sie die tatsächliche Fahrspur.
**Sind BAF/EBS repariert?** Nein, es handelt sich um kraftstoffgebundene schwimmende Zuschläge neben CAF/PSS/PCS/WRS.
**Gebt diese Seite aktuelle Preise an?** Nein; Preise bewegen sich mit dem Markt und werden aus dem formalen Angebot bei der Buchung genommen.

## Bildaufzeichnung
- IMAGE_ASSET_PATH: keine gesicherte Datei
- ORIGINAL_IMAGE_URL: nicht erfasst
- SOURCE_PAGE: nicht erfasst
- RIGHTS_HOLDER: nicht bestätigt
- LICENSE_OR_USAGE_BASIS: keine gesicherte — kein Bild von Dritten darf veröffentlicht werden, bis die Rechte gelöscht sind
- CHECKED_DATUM: 2026-09-05
- MODEL_TOPIC_MATCH: muss mit dem genauen Modell/der genauen Version (oder dem Leitthema) und dem Referenzmarkt oben übereinstimmen
- IMAGE_RIGHTS_STATUS: FAIL (kein lizenziertes Asset erfasst; ein Platzhalter oder ein Hinweis „altes Bild behalten wird nicht akzeptiert)
- ALT nach Sprache:
  - **EN**: AutoBridge export-buyer reference — Ocean freight quotation charge structure, vehicle-export procurement guide
  - **FR**: Référence AutoBridge pour acheteurs export — Ocean freight quotation charge structure, guide d’achat à l’export automobile
  - **DE**: AutoBridge-Referenz für Exportkäufer — Ocean freight quotation charge structure, Leitfaden für Fahrzeugexport-Einkauf
  - **ES**: Referencia AutoBridge para compradores de exportación — Ocean freight quotation charge structure, guía de compras para exportación de vehículos
  - **PT**: Referência AutoBridge para compradores de exportação — Ocean freight quotation charge structure, guia de compras para exportação de veículos
  - **JA**: AutoBridge 輸出バイヤー向けリファレンス｜Ocean freight quotation charge structure, 自動車輸出 調達ガイド
  - **KO**: AutoBridge 수출 바이어 참고 자료｜Ocean freight quotation charge structure, 자동차 수출 조달 가이드
  - **VI**: Tài liệu tham khảo AutoBridge cho người mua xuất khẩu — Ocean freight quotation charge structure, hướng dẫn thu mua xuất khẩu xe
  - **TH**: เอกสารอ้างอิง AutoBridge สำหรับผู้ซื้อเพื่อการส่งออก — Ocean freight quotation charge structure, คู่มือจัดซื้อเพื่อการส่งออกยานยนต์
  - **ID**: Referensi AutoBridge untuk pembeli ekspor — Ocean freight quotation charge structure, panduan pengadaan ekspor kendaraan
  - **AR**: مرجع AutoBridge لمشتري التصدير — Ocean freight quotation charge structure, دليل مشتريات تصدير المركبات
  - **ZH**: AutoBridge 出口采购参考｜Ocean freight quotation charge structure, 汽车出口采购指南

## Quellen & Verifizierung
| Quelle: | Organisation | Markt | URL | Geprüft | Vertrauen | Belegte Fakten |
|---|---|---|---|---|---|---|
| Aufschlüsselung nach FCL-Exportzuschlägen | NetEase | INTL | https://www.163.com/dy/article/L3DE4MEL0556E2ZO.html | 2026-09-04 | CROSS_CHECKED | O/F, THC, DOC, BAF, Auditmethode |
| THC-Definition | Sina Finanzschifffahrt | INTL | https://finance.sina.com.cn/roll/2026-07-31/doc-iniksair4574469.shtml.md | 2026-09-04 | CROSS_CHECKED | Terminalabfertigung |
| Komponenten der Meeresexportabgabe auf der Spur | Kärnten | INTL | https://m.baike.com/wiki/%E6%B5%B7%E8%BF%90%E5%87%BA%E5%8F%A3/7570444 | 2026-09-04 | CROSS_CHECKED | Zusätzliche Taxonomie, AMS/ACI/ENS Routenlogik |
| Gemeinsame FOB-Gebühren (THC/Buchung/Trucking) | 11467 | CN | https://m.11467.com/product/d24491409.htm | 2026-09-04 | SINGLE_SOURCEN | Gebührenbezeichnung |
*Beweisumfang: Gebührenstruktur, die von Branchenquellen abgeglichen wurde (keine offizielle Tarifquelle); AMS/ACI/ENS als streckenspezifische redaktionelle Anleitung eingerahmt; alle Beträge bewusst als zeitsensibel ausgeschlossen. *

| Incoterms 2020 Regeln (wer arrangiert / bezahlt Transport zu jedem Begriff) | Internationale Handelskammer (ICC) | INT'L | https://iccwbo.org/business-solutions/incoterms-rules/incoterms-2020/ | 2026-09-05 | ÜBERPRÜFUNG | Welche Fracht/Gebühren fallen von Incoterm an Käufer vs. Verkäufer |
| Gütertransportunternehmen und Gebührenkategorien | FIATA | INT'L | https://fiata.org/ | 2026-09-05 | ÜBERPRÜFUNG | Referenz Speditionskurs/Entgeltstruktur |
| Linienversand und Zuschlagkontext | World Shipping Council | INT'L | https://www.worldshipping.org/ | 2026-09-05 | ÜBERPRÜFUNG | Branchenkontext für Seefracht- und Nebenkosten |
| China International Speditionsverband | OZF | CN/INT'L | http://www.cifa.org.cn/ | 2026-09-05 | ÜBERPRÜFUNG | China-Seite Speditionsindustrie und Angebotspraxis |

## Editorial Review
- **AutoBridge Export Editorial Team · Methode nach unserer [Editorial Policy](/redaktionelle Politik/)
- **Zuletzt überprüft**: 2026-09-05
- **Referenzmarkt**: Internationale Seefrachtstruktur (keine Beträge, kein fahrspurspezifischer Tarif)
- **Verifizierungsmethode**: Strukturgekreuzt; Routenscoped; Nullfestwerte geltend gemacht
- **Transparenz**: KI-unterstütztes Zeichnen wurde verwendet. Dieser Artikel basiert auf Desk Research und automatisierter QA. Es werden keine Tests aus erster Hand beansprucht, es sei denn, sie sind explizit dokumentiert; zeitsensible und zielspezifische Anforderungen vor der Transaktion bestätigen.
- **Editorialstandard**: Recherchiert und geschrieben aus den oben aufgeführten Quellen (Desk-Recherche; kein Fahren aus erster Hand, Teardown oder Import wird beansprucht). Das Vertrauen in die Quelle wird pro Zeile angezeigt; jeder Punkt, den wir nicht unabhängig bestätigen können, wird als Verifizierungselement dargestellt und nicht als Tatsache behauptet.

**Tags**: #OceanFreight #FreightCharges #THC #ShippingQuote #ExportCost
