# Qingling Isuzu KV100: Sebuah China- Pasar Blue- Plate Referensi Truk Light Dibangun Sekitar GVW, Engine dan Addex Model Lines
## SEO Metadata
- ** Judul SEO **: Qingling Isuzu KV100 Specs truk ringan Pasar  and  Export Checks | AutoBridge
- ** Meta Description **: Referensi pasar untuk Qingling Isuzu KV100 N2 truk lampu biru: 4KH1CN6LB Cina - 6 diesel, rangsel cargo-bed, sisi samping 100P baris tetap terpisah, dan ekspor verifikasi.
- ** H1 **: Qingling Isuzu KV100: Sebuah Pasar Cina Referensi Truk Cahaya Plat Dibangun Sekitar GVW, Engine dan AdvocaModel Lines
- ** Primary Keyword **: Qingling Isuzu KV100 ekspor spesifikasi
- 庆铃 KV100; KV100 4KH1CN6LB; Isuzu truk ringan Cina; truk piring biru; ekspor truk Cina N2; MSB 5MT
- ** Sugested URL **: / kendaraan / qinging -isuzu- kv100/
- ** Cari Intent **: 面向海外买家介绍庆铃 KV100 中国市场身份 = 4KH1 国六柴油 = 货箱长度区间 = 并区分相邻 100P 车型线与全球 ELF = =
- ** Internal Link Sugestions **: / kendaraan / changan-kaicene- f70/, / kendaraan / jmc -ford- transit- t8/, / kendaraan / faw-jiefang- j7-tractor/
- Sebuah Qingling Isuzu KV100 taksi-atas truk kargo ringan yang ditunjukkan dari sisi tiga perempat
- ** ALT Sarankan **: sisi tiga - kuartal tampilan Qingling Isuzu KV100 taksi-atas truk ringan di tanah netral
- ** Skema Scope **: Pasal + Kendaraan (tidak ada Produk / Offer / Harga / Review / Rating)

The Qingling Isuzu KV100 is a cab-over (flat-face) light truck built by Qingling Motors in China for the domestic "blue-plate" N2 category — vehicles with a gross vehicle mass at or below 4.5 t that can be driven under an ordinary light-vehicle licence in China. Untuk pembeli ekspor, disiplin kunci adalah regulasi dan model disiplin baris: pin lengkap akhiran mesin dan Cina yang - 6 tahap emisi, menjaga KV100 terpisah dari berdekatan Qingling / Isuzu baris seperti 100P yang baru, dan tidak mengobati penggunaan-truk muatan diklasifikasikan angka sebagai data pabrik. Halaman ini adalah ** CINESE-pasar referensi ** dan tidak sama dengan Qingling- dibangun KV100 dengan jangkauan global Isuzu N / ELF tanpa pernyataan model OEM.

## Identitas kelas dan tubuh

- Kelas: * Truk ringan N2, GVW 4.5 t ** (Kategori blue- plate Cina), tata letak cab -over (flat--face), diesel (cross- check for model- line identity).
- Panjang kargo-tubuh umum: kira-kira ** 4.2–4.3 m ** untuk kotak / aplikasi flatbed khas (tunggal-sumber) - panjang tubuh yang tepat adalah pilihan superstruktur dan harus cocok dengan chassis tertentu dan homologation nya.

Karena truk cahaya dijual sebagai chassis- taksi ditambah tubuh yang cocok, "KV100" dapat membawa sangat berbeda kotak, taruhan atau badan pendingin. Pembeli harus mengobati spesifikasi chassis dan suprastruktur sebagai dua item verifikasi terpisah dan mengkonfirmasi dimensi kendaraan selesai dan GVW pada sertifikat.

## Powertrain - pin akhiran mesin tepat

| Butir | Referensi pasar-Cina | Percaya diri |
|---|---|---|
| Mesin | 4KH1CN6LB diesel 3.0-litre, China - 6 (National VI) | SINGLE_SOURCE |
| Keluaran | 120 PS / 290 N·m | SINGLE_SOURCE — konfirmasi oleh VIN / OEM|
| Gearbox | Manual MSB 5-speed (5MT) | SINGLE_SOURCE |

Keluarga 4KH1 ada di lebih dari satu akhiran dengan hasil yang berbeda, dan laporan independen kedua mengacu pada rating 4KH1 akhiran yang berbeda. Itulah mengapa kode mesin penuh - ** 4KH1CN6LB **, bukan hanya "a 4KH1" - harus ditulis ke dalam urutan dan cocok dengan entri homologasi MIIT. Cina - 6 diesel dikalibrasi untuk bahan bakar Cina dan VI nasional panggung; tingkat bahan bakar tujuan dan pengakuan emisi harus diperiksa secara terpisah daripada diasumsikan.

## Payload dan kerb mass: classifieds bukan data pabrik

Used-vehicle listings (a T4 classified source) show sample kerb masses around 2.55–2.91 t and rated payloads around 1.495–1.75 t across different bodies. Angka-angka ini ** tidak ** disajikan sebagai spesifikasi: mereka bervariasi dengan tubuh yang cocok, adalah diri-dilaporkan oleh penjual dan tidak dapat digunakan untuk ukuran beban. Muatan berwibawa, massa kerb dan GVW berasal dari ** tepatnya chassis homologation sertifikat / nametation plate *. Menghadang mereka sebelum berkomitmen untuk siklus tugas muatan.

## Advoir baris dan batas global Isuzu

Dua identitas jebakan penting:

1. ** Yang baru 100P (4KB1) adalah baris model yang berbeda. ** Mesin dan spekuensinya tidak akan dipindahkan ke KV100; jangan gabungkan 100P angka menjadi KV100 quotation.
2. ** Qingling KV100 global Isuzu ELF / N- seri secara default. ** Qingling membangun hubungan Isuzu, tapi platform dan branding Kinship tidak menyatakan bahwa bangsa Cina KV100 identik dalam spesifikasi, homologasi, suku cadang atau garansi untuk Peri Isuzu yang dijual di tempat lain. Di bawah aturan mode identitas, ** RELATED _ MODEL ASAME _ MODEL ** tanpa pernyataan eksplisit OEM; jangan mengutip kekuatan global Isuzu, torsi atau daya tahan figure figure untuk truk Cina.

## Batas Steering and export

Chinese- pasar KV100 adalah ** drive tangan kiri **. Hak-tangan-drive eligibilitas, spesifikasi ekspor pabrik apapun dan penamaan model luar negeri memerlukan bukti OEM terpisah. Untuk truk yang bekerja, juga memverifikasi aturan aksel- beban tujuan, kategori lisensi untuk GVW yang selesai, dan apakah mesin Cina - 6 diakui (atau memerlukan membangun emisi berbeda) di pasar target.

## Pembeli verifikasi sebelum deposit

| Periksa | Aksi |
|---|---|
| Kelas / GVW | Konfirmasi kendaraan yang selesai GVW (basis blueplate 4.5 t) dan kategori lisensi tujuan. |
| Mesin | Pin 4KH1CN6LB, 120 PS / 290 N·m dan MSB 5MT ke entri MIIT; membedakan akhiran 4KH1 lainnya. |
| Emisi | Verifikasi Cina - 6 pengakuan dan kompatibilitas bahan bakar tujuan. |
| Tubuh | Perlakukan tubuh kargo (tipikal 4.2–4.3 m) sebagai sustruktur terpisah; konfirmasi dimensi selesai. |
| Isi | Baca muatan berperingkat / massa kerb dari papan nama / sertifikat, tidak digunakan-iklan truk. |
| Identitas | Jauhkan KV100 terpisah dari 100P/4KB1 dan dari global Isuzu ELF kecuali OEM membuktikan kesamaan model; mendamaikan VIN sebelum pembayaran akhir. |

## PSD
** Kategori apa adalah Qingling KV100? **

Ini adalah taksi - lebih dari N2 truk lampu biru dengan GVW di atau di bawah 4.5 t, biasanya dilengkapi dengan sekitar 4.2–4.3 m kargo tubuh.

Mesin apa yang digunakan? **

Baris referenced menggunakan 4KH1CN6LB 3.0-litre China- 6 diesel dikutip pada 120 PS / 290 N·m dengan MSB 5MT; pin akhiran penuh karena lain 4KH1 peringkat ada.

** Apa payload nya? **

Tidak ada muatan tetap yang dinyatakan di sini - sampel rahasia bervariasi dan tidak data pabrik; membaca muatan rated dan GVW dari sertifikat chassis yang tepat.

Apakah KV100 sama seperti Peri Isuzu? ♪ ♪

Tidak pada bukti ini: itu Qingling- dibangun untuk Cina dan diperlakukan sebagai model terkait sampai pernyataan model OEM ada.

Apakah truk yang baru 100P sama? **

No — the 100P (4KB1) is a separate model line whose figures must not be merged into a KV100 specification.

## Sumber & Verifikasi
| Sumber | Organisasi | Pasar | Tier | Percaya diri | URL | Fakta yang didukung |
|---|---|---|---|---|---|---|
| KV100 4KH1 发动机 / 变速箱 / 国六 | 卡车之家官方号 (今日头条镜像) | CN | T3 | SINGLE_SOURCE | http://m.toutiao.com/group/6909341128869315076/ | 4KH1 发动机, 变速箱, 国六 |
| 4KH1 另一后缀功率 = 区分后缀 = | 卡车之家官方号 (今日头条镜像) | CN | T3 | SINGLE_SOURCE | http://m.toutiao.com/group/6891911045259100683/ | 4KH1 另一后缀功率 |
| 相邻车型线区分: 100P 等 | 提加商用车网 (今日头条镜像) | CN | T3 | SINGLE_SOURCE | http://m.toutiao.com/group/7351812463941190163/ | 相邻车型线区分 |
| 二手样本载质量线索: 不作规格 | 58同城 | CN | T4 | UNVERIFIED | https://m.58.com/sz/huochec/60462479681462x.shtml | 载质量线索 |
| 庆铃汽车官方网站（车型线身份；exact-trim以官方/公告终核） | 庆铃汽车 (Qingling Isuzu) | CN | T1 | VERIFIED | https://www.qingling.com.cn/ | 车型线身份 |

## Editorial Review
- ** Penulis **: Tim Editorial AutoBridge Ekspor
- ** Terakhir ditinjau **: 2026-09-07
- ** Referensi pasar **: CHINA（中国市场蓝牌轻卡参考；4KH1功率为单一来源，二手载质量为T4不作规格，与全球Isuzu ELF不自动同型）
- ** Metode Verifikasi **: Penelitian terhadap sumber di bawah ini; spesifikasi referensi pasar Cinese- kecuali pasar ekspor terpisah secara eksplisit dikutip. Hasil produksi mesin sumber tunggal dan semua muatan berperingkat / angka GVW harus dikonfirmasi kembali pada lembar OEM atau entri homologasi MIIT, dan status yang sama dengan Isuzu global membutuhkan pernyataan eksplisit OEM sebelum melakukan transakting.
- ** Transparansi **: penggambaran bantuan digunakan. Artikel ini didasarkan pada penelitian meja dan otomatis QA. Tidak ada pengujian pertama-tangan diklaim kecuali secara eksplisit didokumentasikan.
