# Dongfeng Aeolus Yixuan: CMP Pasar Cina Referensi Sedan Kompak, Baris Kini vs Versi Mach Lebih Lama
## SEO Metadata
- ** Judul SEO **: Dongfeng Aeolus Yixuan China- Pasar Specs  and  Export Buyer Checks | AutoBridge
- ** Meta Description **: Referensi pasar Cina untuk sedan pos CMP Dongfeng Aeolus Yixuan: dimensi, baris berbanding 2025 1.5L saat ini dibandingkan Mach 1.5T yang lebih tua tetap terpisah, dan VIN-level cek untuk pembeli ekspor.
- ♪ ♪ H1 Sebuah CMP Pasar Cina Referensi Sedan Kompak, Baris Kini vs Versi Mach Lebih Lama
- ** Primary Keyword **: Spesifikasi ekspor Dongfeng Aeolus Yixuan
- ** Akhir Pencarian Second **: 东风风神奕炫; dimensi Aeolus Yixuan; ekspor SEDAN Yixuan 1.5L; Mach 1.5T; ekspor CMP Cina
- ** Sugesti URL **: / kendaraan / dongfeng-aeolus- yixuan /
- ** Cari Intent **: 面向海外买家介绍风神奕炫中国市场身份 = 尺寸 = 当前 1.5L 与较早马赫版 1.5T 的版本边界 = =
- ** Internal Link Sugestions **: / kendaraan / jeju-gagah /, / kendaraan / saic-maxus - g90/, / guide / verify- chine- ekspor-ekspor-supplier-history /
- ** Sugesti Gambar **: Sebuah Auolus Dongfeng Yixuan sedan cepat menunjukkan dari depan tiga perempat pada latar belakang netral
- ** ALT Sarankan **: Tampilan tiga perempat depan dari sebuah pemandangan Dongfeng Aeolus Yixuan sedan pada latar belakang studio netral
- ** Skema Scope **: Pasal + Kendaraan (tidak ada Produk / Offer / Harga / Review / Rating)

Dongfeng Aeolus Yixuan (风神奕炫) adalah kotak tiga kotak / sedan cepat yang dibangun di platform CMP  and  dijual di Cina di bawah Dongfeng Aeolus (Fengshen) merek kendaraan penumpang. Pembeli risiko dalam model ini adalah sementara daripada struktural: Jalur penjualan 2025 sekarang adalah alami - diaspirasi 1.5-litre mobil,  while the higher-output "Mach" (马赫) 1.5T belongs to an earlier 2022/2023 powertrain wave. Mengkueri keluaran Turbo yang lebih tua seolah-olah itu adalah sedan saat ini adalah versi yang paling umum kesalahan. Halaman ini adalah ** Referensi pasar Cinese- **, bukan lembar spesifikasi global; versi pasar ekspor perlu terpisah bukti OEM, dan keluaran sumber tunggal ditandai untuk konfirmasi.

## Identitas tubuh dan dimensi

- Tubuh: empat pintu, lima kursi kotak kompak / sedan cepat di platform CMP, depan mesin / depan-roda drive (cross- check).
- Dimensi referensi: ** 4670 × 1812 × 1490 mm, wheelbase 2680 mm **. perhatikan asli 2019 peluncuran mobil terdaftar 4660 mm panjang; kecil tahun-over- tahun perbedaan harus cocok dengan model yang tepat - tahun daripada dicampur.

Dasar CMP sinyal sebuah Torsion- beam / transverse- tata letak drive ditujukan pada segmen-sedan-sedan-sedan; suspensi dan detail peralatan yang tepat untuk SKU yang diberikan masih harus dibaca dari lembar konfigurasi SKU itu.

## Baris ini melawan versi Mach yang lebih tua - memisahkan mereka

| Baris | Referensi pasar-Cina | Gearbox | Periode / status | Percaya diri |
|---|---|---|---|---|
| 1.5L alami aspirasi (2025) | 92 kW (125 PS) / 158 N·m; WLTC dikombinasikan oleh £6.24 L / 100 km | 6-speed dual- kopling basah | 2025 baris utama saat ini | SINGLE_SOURCE — konfirmasi oleh VIN / OEM|
| Mach 1.5T (马赫版) | 145 kW (197 PS) / 300 N·m | Getrag 6-speed basah dualkopling | 2022/2023 lebih tua garis, bukan 2025 baris utama | SINGLE_SOURCE — baris historis|

Jarak kinerja antara keduanya cukup besar untuk mengubah keputusan pembeli, itulah sebabnya mereka tidak harus bergabung menjadi satu "Mesin Yixuan". Gach 1.5T harus diberi label sebagai ** sebelumnya ** kereta api, menyajikan sebagai sedan yang tersedia saat ini akan salah mewakili line- up. Kedua keluaran saat ini beristirahat pada satu sumber independen dan harus ditutup terhadap halaman konfigurasi resmi Aeolus atau entri homologasi MIIT tepat sebelum kontraksi. Konsumsi bahan bakar dikutip pada siklus ** WLTC ** dan tidak boleh dibandingkan dengan NEDC atau CLTC angka dari mobil lain.

## Peralatan dan disiplin trim

Seperti kebanyakan sedan kompak Cina, teknologi yang terlihat - layar lebar, driver- membantu, pencahayaan dan fungsi kursi - memanjat dengan trim dan perubahan per tahun. Ulasan edisi Mach High Spec bukanlah bukti bahwa pertengahan 2025 1.5L membawa peralatan yang sama. Tentukan nama dan model tahun yang tepat dan buat perintah terhadap lembar SKU itu.

## Harga, kemudi dan batas ekspor

Harga panduan Cina adalah ** waktu-sensitif dalam negeri saja ** dan tidak pernah FOB / CIF harga ekspor; tidak ada harga ekspor yang dinyatakan di sini. Mobil Cina yang direferensikan adalah ** drive tangan kiri **; tidak ada bukti OEM dalam berkas ini yang membangun pabrik RHD Yixuan, jadi kanan-drive pasar perlu jawaban merek terpisah. Setiap luar negeri Aeolus / Dongfeng sedan diperlakukan sebagai terkait tetapi tidak secara otomatis identik membangun kecuali sebuah pernyataan OEM-model ada.

## Pembeli luar negeri verifikasi sebelum deposit

1. Perbaiki apakah tawaran ini sekarang 2025 1.5L baris atau Mach 1.5T tua, dan label periode jujur.
2. Konfirmasi keluaran, gearbox, dan konsumsi WLTC terhadap lembar OEM / MIIT entri (keduanya tunggal-sumber di sini).
3. Cocok dimensi dan 4660-vs-4670 panjang pertanyaan ke model-tahun CoC yang tepat.
4. Konfirmasi LHD / RHD dan destination- spesifikasi pasar secara terpisah dengan merek tersebut.
5. Reconcile VIN di seluruh kontrak, faktur, B / L dan CoC sebelum pembayaran akhir.
6. Uji bahasa unit kepala, koneksi band dan aplikasi tersedia untuk tujuan.

## PSD
Mesin apa yang digunakan Aeolus Yixuan saat ini? **

Jalur utama 2025 yang direferensikan di sini adalah 1.5L alami yang dianjurkan oleh 92 kW / 158 N·m dengan 6DCT dan WLTC menggabungkan penggunaan bahan bakar sekitar 6.24 L / 100 km; konfirmasi oleh VIN.

Apa 197-PS Mach 1.5T mobil yang sekarang? **

Tidak - Mach 1.5T (145 kW / 300 N·m, Getrag 6DCT) adalah garis 2022/2023 tua dan tidak boleh disajikan sebagai Sedan 2025 on-penjualan.

** Peron apa dan tata letak drive? ♪ ♪

Menggunakan platform CMP dan mesin / depan-roda.

** Apa dimensi nya? **

Dimensi referensi 4670 × 1812 × 1490 mm dengan sebuah pangkalan roda 2680 mm; 2019 peluncuran mobil terdaftar 4660 mm panjang, jadi cocokkan tahun.

** Apakah versi right- hand- drive tersedia? ♪ ♪

Tak ada RHD pabrik yang didirikan oleh sumber pasar Cinese- di sini; spesifikasi RHD dan ekspor memerlukan bukti OEM terpisah.

## Sumber & Verifikasi
| Sumber | Organisasi | Pasar | Tier | Percaya diri | URL | Fakta yang didukung |
|---|---|---|---|---|---|---|
| 奕炫参数 = 2025 款动力 / 尺寸 / 轴距 | 懂车帝车型参数页 | CN | T2 | CROSS_CHECKED | https://m.dongchedi.com/auto/params-carIds-248306-248307-248571-245458-97522-97523-79598 | 2025 款动力, 尺寸, 轴距 |
| 奕炫尺寸 / 轴距 | 搜狐汽车 | CN | T3 | SINGLE_SOURCE | http://db.m.auto.sohu.com/model_5991/a/995643471_120590677 | 尺寸, 轴距 |
| 马赫版 1.5T/ 变速箱 = 较早动力线 = | 太平洋汽车 (今日头条镜像) | CN | T3 | SINGLE_SOURCE | http://m.toutiao.com/group/7159927255685956132/ | 马赫版 1.5T, 变速箱 |
| 东风风神官方网站（车型线身份；exact-trim以官方配置表终核） | 东风乘用车·东风风神(Aeolus) | CN | T1 | VERIFIED | https://www.dfpv.com.cn/ | 车型线身份 |

## Editorial Review
- ** Penulis **: Tim Editorial AutoBridge Ekspor
- ** Terakhir ditinjau **: 2026-09-07
- ** Referensi pasar **: CHINA（中国市场参考；1.5L与马赫1.5T精确功率为单一来源，须风神官方/公告按年款SKU终核）
- ** Metode Verifikasi **: Penelitian terhadap sumber di bawah ini; spesifikasi referensi pasar Cinese- kecuali pasar ekspor terpisah secara eksplisit dikutip. Hasil tunggal sumber, garis tipis dan harga referensi domestik harus dikonfirmasi kembali pada lembar OEM atau entri MIIT sebelum melakukan transakting.
- ** Transparansi **: penggambaran bantuan digunakan. Artikel ini didasarkan pada penelitian meja dan otomatis QA. Tidak ada pengujian pertama-tangan diklaim kecuali secara eksplisit didokumentasikan.
