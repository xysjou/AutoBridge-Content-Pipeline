# Qingling Isuzu KV100: Una China-Market Blue-Plate Light Truck Referencia Construida alrededor de GVW, Motor y Líneas de Modelo Adyacente
## SEO Metadatos
- **SEO Título**: Qingling Isuzu KV100 China-Market Light Truck Specs and Export Checks TENIENDO AutoBridge
- **Meta Descripción**: Referencia del mercado chino para el camión de luz Qingling Isuzu KV100 N2 de placa azul: el diesel 4KH1CN6LB China- 6 China, rango de carga, línea adyacente 100P se mantuvo separado, y verificación de exportación.
- ** H1 **: Qingling Isuzu KV100: Una China-Market Blue-Plate Light Truck Referencia Construida alrededor de GVW, Motor y Líneas de Modelo Adyacentes
- **Primary Keyword**: Qingling Isuzu KV100 export specs
- ** Términos de búsqueda de la segunda reunión**: 庆铃 KV100; KV100 4KH1CN6LB; Isuzu camión ligero China; camión de placa azul; China N2 camiones export; MSB 5MT
- ** URL agregada**: /vehicles/qingling-isuzu- kv100/
- **Búsqueda Intent**: 面向海外买家介绍庆铃 KV100 中国市场身份, 4KH1 国六柴油, 货箱长度区间, 并区分相邻 100P 车型线与全球 ELF
- **Sugerencias de Enlace Interno**: /vehicles/changan-kaicene- f70/, /vehicles/jmc-ford-transit- t8/, /vehicles/faw-jiefang- j7-tractor/
- **Sugerencia de imagen**: Un camión de carga ligera Qingling Isuzu KV100 que se muestra desde el lado tres cuarto
- **ALT Sugerencia**: Vista lateral de tres cuartos de un camión ligero Qingling Isuzu KV100 sobre la cabina en tierra neutral
- **Esquema de alcance**: Artículo + Vehículo (no Producto/Offer/Precio/Revisión/Revisión)

El Qingling Isuzu KV100 es un camión ligero de la cabina (cara plana) construido por Qingling Motors en China para la categoría "plano azul" N2 nacional — vehículos con una masa de vehículo bruto a o menos 4.5 t que pueden ser impulsados bajo una licencia de vehículos ligeros ordinarios en China. Para un comprador de exportación las disciplinas clave son la disciplina regulatoria y modelo-line: pin el sufijo del motor exacto y su China- 6 etapa de emisión, mantener las KV100 separadas de las líneas adyacentes Qingling/Isuzu como el nuevo 100P, y no tratar las cifras de carga de pago clasificadas de la caja utilizada como datos de fábrica. Esta página es una referencia **Chino-mercado** y no equipara el Qingling-construido KV100 con el rango global Isuzu N/ELF sin una declaración OEM del mismo modelo.

## Identidad y cuerpo de clase

- Clase: ** N2 camiones ligeros, GVW ≤ 4.5 t ** (categoría china de placa azul), diseño de la cabina (cara plana), diesel (contra-controlado para la identidad modelo).
- Longitud común de carga: aproximadamente ** 4.2–4.3 m** para aplicaciones típicas de caja/plano (fuente individual) — la longitud exacta del cuerpo es una opción de superestructura y debe ser igualada al chasis específico y su homologación.

Debido a que los camiones ligeros se venden como una costra de chasis más un cuerpo equipado, "a KV100 " puede llevar cajas muy diferentes, estacas o cuerpos refrigerados. El comprador debe tratar la especificación de chasis y la superestructura como dos elementos de verificación separados y confirmar las dimensiones del vehículo terminado y GVW en el certificado.

## Powertrain: pin el sufijo del motor exacto

| Tema | Referencia del mercado chino | Confianza |
|---|---|---|
| Motor | ** 4KH1CN6LB ** 3.0-litre diesel, China- 6 (Naciones Unidas VI) | SINGLE_SOURCE |
| Producto | 120 PS / 290 N·m | SINGLE_SOURCE — confirm by VIN/OEM|
| Caja de cambios | Manual de MSB 5-speed (5MT) | SINGLE_SOURCE |

La familia 4KH1 existe en más de un sufijo con diferentes productos,  and  un segundo informe independiente hace referencia a una calificación de sufijo 4KH1 diferente. Es por eso que el código completo del motor — ** 4KH1CN6LB **, no sólo "a 4KH1 " — debe ser escrito en el orden y coincide con la entrada de homologación MIIT. Un diesel China- 6 está calibrado para el combustible chino y la etapa VI nacional; El grado de combustible de destino y el reconocimiento de emisiones deben ser revisados por separado en lugar de asumirlo.

## Carga de carga y masa de kerb: los anuncios no son datos de fábrica

Used-vehicle listings (a T4 classified source) show sample kerb masses around 2.55–2.91 t and rated payloads around 1.495–1.75 t across different bodies. Estas cifras son **no** presentadas como especificaciones: varían con el cuerpo equipado, son auto-reportados por los vendedores y no se puede utilizar para tamaño una carga. La carga útil autorizada, masa de kerb y GVW provienen del certificado de homologación de chasis de **exacto / placa de nombre**. Obtenga a los que antes de comprometerse a un ciclo de servicio de carga útil.

## Líneas adyacentes y el límite global Isuzu

Dos trampas de identidad importan:

1. **El nuevo 100P (4KB1) es una línea de modelo diferente.** Su motor y especificación no se transfiere a los KV100; do not blend 100P figures into a KV100 quotation.
2. **Pendiente KV100 √ Global Isuzu ELF/N-series por defecto.** Qingling construye bajo su relación Isuzu, pero los parientes de plataforma y marca no establecen que el chino KV100 es idéntico en especificación, homologación, partes o garantía a un Elf Isuzu vendido en otro lugar. Bajo la regla de identidad modelo **RELATED_MODEL √DEL √SAME_MODEL** sin una declaración explícita de OEM; no citen las figuras globales de potencia, par o durabilidad del camión chino.

## Límite de dirección y exportación

El mercado chino referenciado KV100 es **accionamiento de mano izquierda**. Elegibilidad de mano derecha, especificación de exportación de fábrica y designación de modelos en el extranjero requieren pruebas OEM separadas. Para un camión de trabajo, también verifique las reglas de carga de eje del destino, la categoría de licencia para el GVW terminado, y si el motor China- 6 es reconocido (o necesita una construcción de emisiones diferente) en el mercado objetivo.

## Verificación del comprador antes del depósito

| Check | Medida |
|---|---|
| Clase/GVW | Confirme el GVW del vehículo terminado (≤ 4.5 t base azul-plate) y la categoría de licencia de destino. |
| Motor | Pin 4KH1CN6LB, 120 PS / 290 N·m y MSB 5MT a la entrada MIIT; distinguir otros 4KH1 sufijos. |
| Emission | Verificar el reconocimiento China- 6  and  compatibilidad de combustible de destino. |
| Cuerpo | Cuerpo de carga de Treat (TÉ 4.2–4.3 m típico) como superestructura separada; confirme las dimensiones terminadas. |
| Carga de pago | Lea la masa nominal de payload/kerb del nameplate/certificate, no los anuncios de la caja utilizada. |
| Identidad | Mantenga KV100 separado de la 100P/4KB1 y del ELF Isuzu global a menos que OEM demuestre el mismo modelo; reconcilie VIN antes del pago final. |

## FAQ
**¿Qué categoría es el Qingling KV100 ?**

Es un camión ligero de placa azul con cable N2 con GVW en o debajo de 4.5 t, normalmente equipado con un cuerpo de carga de aproximadamente 4.2–4.3 m.

**¿Qué motor utiliza? ################################################################################################################################################################################################################################################################

La línea referenciada utiliza el diesel 4KH1CN6LB 3.0-litre China- 6 citado en 120 PS / 290 N·m con un MSB 5MT; pin el sufijo completo porque existen otras 4KH1 valoraciones.

**¿Cuál es su carga útil? ################################################################################################################################################################################################################################################################

No se indica ninguna carga de pago fija aquí — las muestras clasificadas varían y no son datos de fábrica; la descarga de pago nominal y GVW del certificado de chasis exacto.

**¿Es el KV100 igual que un Elfo Isuzu global? **

No en esta evidencia: está Qingling-construido para China y se trata como un modelo relacionado hasta que exista una declaración OEM de la misma modelo.

**¿El nuevo 100P es el mismo camión? ################################################################################################################################################################################################################################################################

No — the 100P (4KB1) is a separate model line whose figures must not be merged into a KV100 specification.

## Fuentes " Verificación "
| Fuente | Organización | Mercado | Tier | Confianza | URL | Datos respaldados |
|---|---|---|---|---|---|---|
| KV100 4KH1 发动机 / 变速箱 / 国六 | 卡车之家官方号 (今日头条镜像) | CN | T3 | SINGLE_SOURCE | http://m.toutiao.com/group/6909341128869315076/ | 4KH1 发动机, 变速箱, 国六 |
| 4KH1 另一后缀功率 (区分后缀) | 卡车之家官方号 (今日头条镜像) | CN | T3 | SINGLE_SOURCE | http://m.toutiao.com/group/6891911045259100683/ | 4KH1 另一后缀功率 |
| 相邻车型线区分 (100P 等) | 提加商用车网 (今日头条镜像) | CN | T3 | SINGLE_SOURCE | http://m.toutiao.com/group/7351812463941190163/ | 相邻车型线区分 |
| 二手样本载质量线索 (不作规格) | 58同城 | CN | T4 | UNVERIFIED | https://m.58.com/sz/huochec/60462479681462x.shtml | 载质量线索 |
| 庆铃汽车官方网站 (车型线身份;exact-trim 以官方 / 公告终核) | 庆铃汽车 (Qingling Isuzu) | CN | T1 | VERIFIED | https://www.qingling.com.cn/ | 车型线身份 |

## Revisión editorial
- **Autor**: Equipo Editorial AutoBridge Export · [autores](/autores/) · [Política editorial](/editorial-policía/)
- **Documento revisado*: 2026-09-07
- **Mercamiento de referencia**: CHINA(中国市场蓝牌轻卡参考; 4KH1 功率为单一来源, 二手载质量为 T4 不作规格, 与全球 Isuzu ELF 不自动同型)
- **Método de verificación**: Investigación de escritorio contra las fuentes siguientes; especificación de referencia del mercado chino solamente a menos que se mencione explícitamente un mercado de exportación separado. Las salidas de motor de un solo proveedor y todas las cifras de payload/GVW nominales deben ser confirmadas en la hoja OEM o entrada de homologación MIIT, y el estado de la misma modelo con Isuzu global requiere una declaración OEM explícita antes de la transacción.
- **Transparencia**: Se utilizó la redacción con ayuda de AI. Este artículo se basa en la investigación de escritorio y QA automatizado. No se reclaman pruebas de primera mano a menos que se documenten explícitamente.
