# Customs Codes 9710 and 9810: How China's Cross-Border B2B Export Regimes Actually Differ
## SEO Metadata
- **SEO Title**: China Cross-Border B2B Export 9710 vs 9810 Overseas Warehouse | AutoBridge
- **Meta Description**: What customs supervision codes 9710 and 9810 mean, how direct B2B export differs from overseas-warehouse export, the registration and filing required, and what a vehicle exporter must confirm with local customs.
- **H1**: Customs Codes 9710 and 9810: How China's Cross-Border B2B Export Regimes Actually Differ
- **Primary Keyword**: cross border ecommerce b2b export 9710 9810
- **Secondary Search Terms**: 9710 customs code; 9810 overseas warehouse export; China B2B cross-border e-commerce; overseas warehouse filing; cross-border e-commerce customs registration
- **Suggested URL**: /guides/cross-border-ecommerce-b2b-export-9710-9810/
- **Search Intent**: 9710与9810两种跨境电商B2B出口监管方式的区别、海外仓模式的时点分离与备案、企业需要哪些资质
- **Internal Link Suggestions**: /guides/export-returned-goods-duty-exemption-regulation/, /guides/china-e-port-enrollment-ic-card-operator/, /guides/comprehensive-bonded-zone-vat-refund-export/
- **Image Suggestion**: A logistics coordinator matching an overseas-warehouse waybill to a cross-border declaration on screen
- **ALT Suggestion**: Desk with an overseas-warehouse waybill and a cross-border customs declaration on a monitor
- **Schema Scope**: Article (no Product/Offer/Price/Review/Rating)

China added two dedicated customs supervision codes for business-to-business cross-border e-commerce exports after pilot programmes proved the model: **9710** for cross-border e-commerce B2B direct export and **9810** for cross-border e-commerce export to overseas warehouses. The numbers look interchangeable, but they describe different commercial timelines, and choosing the wrong one changes when a sale is recognised, how goods are declared, and what filings must exist beforehand. This guide explains each code, the eligibility setup that precedes either, and the questions a vehicle or parts exporter must put to the local supervising customs rather than answer by assumption.

## 9710: B2B direct export

Under **9710**, a Chinese enterprise exports goods directly to an overseas business buyer through a cross-border e-commerce platform or channel, with the B2B transaction established at the point of export. In commercial shape it is closest to a conventional export: the goods, the overseas business customer and the transaction line up in one movement, but the declaration uses the cross-border B2B channel and can draw on its simplified, data-driven clearance arrangements.

## 9810: export to an overseas warehouse — the timing that matters

Under **9810**, goods are exported first to an **overseas warehouse** abroad and are only sold to the overseas buyer later, out of that warehouse. Export and sale are deliberately separated in time: the consignment leaves China before the end-customer transaction exists. That is the defining difference from 9710 and the source of most compliance questions.

Because goods move before the final sale, the overseas warehouse is part of the regulatory picture. The overseas warehouse used under 9810 is subject to filing/record requirements (cross-checked across customs guidance and trade-promotion materials), and the enterprise must be able to connect the outbound export to the later outbound-from-warehouse sale through platform and logistics data. An exporter cannot simply label any foreign stockroom a "9810 overseas warehouse"; the warehouse and the data chain must meet the channel's requirements.

## The setup required before either code can be used

Neither code is available to an unregistered entity. The enterprise must complete the standard customs registration as a foreign-trade operator, complete the cross-border e-commerce record, and declare through the designated channel — either the customs system or the China International Trade Single Window. After the initial pilots, the model was rolled out more broadly across customs districts, but operational details, accepted document sets and facilitation measures can still vary by customs district, so the local supervising customs is the operational authority for how a declaration is lodged there.

The data discipline is stricter than for a casual parcel flow: platform transaction data, logistics data and, for 9810, warehouse receipt and subsequent sale data should reconcile. Building that three-way match before volume grows is far cheaper than reconstructing it during an audit or a rebate review.

## The vehicle question — do not assume the answer

A common question is whether **whole vehicles** can move under 9710 or 9810. This guide does not give a blanket yes or no, because eligibility for a specific commodity is administered by the supervising customs in light of the channel rules and the goods involved. A vehicle exporter considering either code should confirm in writing with the local customs whether the specific commodity (finished vehicle versus parts and accessories), the chosen platform and the overseas-warehouse arrangement qualify, before building a sales channel around the code. Parts and accessories fit the e-commerce logic more readily than a finished road vehicle, but "more readily" is not an approval.

## Choosing and operating the right code

| Dimension | 9710 B2B direct export | 9810 overseas-warehouse export |
|---|---|---|
| Transaction timing | Overseas B2B buyer established at export | Goods exported first, sold later from warehouse abroad |
| Core document logic | Transaction + logistics aligned at exit | Export data, warehouse receipt and later sale data chained |
| Extra element | B2B channel/platform record | Overseas warehouse filing and inventory-to-sale traceability |
| Typical fit | Direct business-to-business orders | Stock-forward models serving regional demand |
| Local variation | Confirm document set with local customs | Confirm warehouse eligibility and data rules locally |

## Practical pitfalls

- **Mixing the codes by convenience.** Declaring stock-forward business as 9710 to avoid warehouse filing misstates the transaction timeline.
- **Skipping the cross-border e-commerce record.** Customs registration alone is not the same as the channel-specific filing.
- **Weak 9810 data chains.** If export, warehouse receipt and eventual sale cannot be reconciled, later tax and rebate treatment becomes hard to defend.
- **Assuming rebate outcomes.** Tax rebate treatment under these channels follows the tax authority's current rules and must be confirmed for the actual case; no fixed rebate figure is assumed here.
- **Treating pilot-era guidance as universal.** Procedures expanded after piloting; always work from the current local customs position.

## FAQ
**What is the difference between 9710 and 9810?**

9710 is B2B direct export with the business sale established at export; 9810 exports goods first to an overseas warehouse and sells them later, separating export from sale.

**Does 9810 require the overseas warehouse to be filed?**

The overseas warehouse used under 9810 is subject to filing/record requirements and must support the export-to-sale data chain; confirm the current local requirements.

**What registrations does an enterprise need?**

Customs foreign-trade registration plus the cross-border e-commerce record, with declarations lodged through the designated customs or Single Window channel.

**Can finished vehicles use 9710 or 9810?**

Do not assume — confirm eligibility for the specific commodity and arrangement in writing with the supervising customs; parts and accessories typically fit the channel logic more readily than whole vehicles.

**Are tax rebates fixed under these codes?**

No. Rebate treatment follows current tax-authority rules and varies by case; confirm the actual treatment rather than relying on a quoted percentage.

## Sources & Verification
| Source | Organization | Market | Tier | Confidence | URL | Supported facts |
|---|---|---|---|---|---|---|
| 关于增列跨境电子商务监管方式（9710/9810定义、代码）公告附件 | 中华人民共和国海关总署 | CN | T1 | VERIFIED | http://www.customs.gov.cn/customs/fileDir/resource/cms/article/302267/3183138/2020070916175637208.pdf | 9710/9810定义, 增列代码 |
| 跨境电商B2B出口监管（企业备案、通关） | 中华人民共和国海关总署 | CN | T1 | VERIFIED | http://www.customs.gov.cn/customs/2020-07/09/article_2025121221010360532.html | 9710/9810, 企业备案, 通关 |
| 试点推广与适用范围 | 中华人民共和国海关总署 | CN | T1 | VERIFIED | http://www.customs.gov.cn/customs/2021-06/30/article_2025121220574619165.html | 试点推广, 适用范围 |
| 跨境电商B2B出口操作流程与场景 | 海关总署广东分署 | CN | T1 | VERIFIED | http://gdfs.customs.gov.cn/beijing_customs/ztzl1/cjsfw58/kjdscjhfw/index.html | 操作流程, 场景 |
| 跨境电商出口退税衔接与合规要点（贸促系统） | 四川贸促会 | CN | T1 | VERIFIED | https://www.ccpit-sichuan.org/newshow.aspx?id=17802&mid=91 | 退税衔接, 合规要点 |
| 中国国际贸易单一窗口（线上申报主通道） | 中国国际贸易单一窗口 | CN | T1 | VERIFIED | https://www.singlewindow.cn/ | 单一窗口申报通道 |

## Editorial Review
- **Author**: AutoBridge Export Editorial Team · [authors](/authors/) · [Editorial Policy](/editorial-policy/)
- **Last reviewed**: 2026-09-07
- **Reference market**: CN（中国出口侧跨境电商B2B监管；具体商品准入与属地操作以主管海关当期口径为准）
- **Verification method**: Desk research against the sources below; Chinese-market reference framework only. Whether a specific commodity qualifies, local pilot differences and rebate outcomes must be confirmed with the supervising customs and tax authority before transacting.
- **Transparency**: AI-assisted drafting was used. This article is based on desk research and automated QA. No first-hand testing is claimed unless explicitly documented.
